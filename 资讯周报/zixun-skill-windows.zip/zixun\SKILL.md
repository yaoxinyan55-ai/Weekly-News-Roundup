---
name: zixun
description: 微信公众号资讯采集工具。当用户需要采集、搜索、收集公众号文章资讯时使用此 skill。与 gongzhonghao 的区别：JSON 输出只包含标题、来源公众号、发布时间、链接四个字段（不保留正文），但爬取时会提取正文以辅助解析发布时间。触发场景：用户提到"采集资讯"、"搜集资讯"、"zixun"，或需要快速获取公众号文章列表（不需要正文内容）时。
---

# zixun - 微信公众号资讯采集 Skill

通过微信公众号平台后台自动化操作，搜索指定公众号并批量采集文章资讯信息（标题、来源公众号、发布时间、链接），输出为表格形式的 Word 文档。

> **与 gongzhonghao 的区别**：gongzhonghao 会提取完整正文内容；zixun 只采集元信息（标题、来源、时间、链接），速度更快，适合做资讯汇总和行业监控。

## 触发条件

当用户提出以下需求时自动触发：
- 采集/搜集/搜索某个公众号的资讯信息
- 明确提到"zixun"
- 要求获取公众号文章列表（不需要正文内容）
- 行业资讯监控、竞品动态跟踪

## 输入参数

用户需提供以下信息（若未提供则主动询问）：
1. **公众号名称**（必填）：要采集的目标公众号，如"DataEye短剧观察"
2. **时间范围**（必填）：如"近一周"、"前两周"、"近一个月"等

## 输出字段

每条资讯只包含以下 4 个字段：

| 字段 | 说明 |
|------|------|
| 标题 | 文章标题 |
| 来源公众号 | 公众号名称 |
| 发布时间 | 文章发布时间 |
| 链接 | 文章 URL |

## 执行流程

### 第一步：解析用户意图

从用户消息中提取：
- 公众号名称
- 时间范围，根据运行当天（中国大陆日期 UTC+8）往前推算起止日期
  - "今天" = 当天
  - "昨天" = 前一天
  - "近一周" / "前一周" = 最近 7 天
  - "近两周" / "前两周" = 最近 14 天
  - "近一个月" = 最近 30 天
  - 支持"N天前"等自然语言表述

### 第二步：影刀浏览器启动与 CDP 连接

**必须按以下顺序执行，不得跳步，不得重复思考。**

> **Windows 用户注意事项**：运行脚本前需设置 UTF-8 编码环境变量（避免 emoji 等字符报错）：
> ```powershell
> $env:PYTHONIOENCODING="utf-8"
> ```
> 或在每次运行前加 `-X utf8` 参数：`python -X utf8 script.py`

直接运行检测脚本（脚本位于 skill 的 `scripts/` 目录）：

```bash
python {SKILL_DIR}/scripts/browser_check.py --login
```

脚本输出 JSON，根据结果**立即**做以下判断（无需额外思考）：

| `browser_running` | `login_status` | 执行动作 |
|---|---|---|
| false | `"logged_in"` | 浏览器已被脚本自动启动并就绪，**直接跳第四步** |
| false | `"need_login"` | 浏览器已启动，**进入第三步**（扫码登录） |
| false | `"unknown"` | 浏览器启动失败，告知用户手动打开影刀浏览器后重试 |
| true | `"logged_in"` | **直接跳第四步**，不做任何登录操作 |
| true | `"need_login"` | **进入第三步**（扫码登录流程） |
| true | `"unknown"` | 导航到 `https://mp.weixin.qq.com` 后重新运行脚本一次；若仍 unknown 则告知用户 |

> 脚本已内置轮询逻辑（每 500ms 检测一次，最多等 15 秒），**不需要手动 sleep 或等待**。

### 第三步：未登录时的扫码流程（已登录则跳过此步）

> ⚠️ **只有 `login_status == "need_login"` 时才执行此步，已登录直接跳第四步。**

1. 通过 Playwright 连接 CDP，截图二维码元素，保存到桌面：

```python
from playwright.async_api import async_playwright
import time, urllib.request, json, os, sys

# Windows 下 localhost 可能被系统代理干扰，强制绕过代理获取 WebSocket URL
def get_ws_url():
    try:
        proxy_handler = urllib.request.ProxyHandler({})
        opener = urllib.request.build_opener(proxy_handler)
        with opener.open("http://localhost:9222/json/version", timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("webSocketDebuggerUrl", "")
    except Exception:
        return ""

ws_url = get_ws_url()

async with async_playwright() as p:
    browser = await p.chromium.connect_over_cdp(ws_url)
    context = browser.contexts[0]
    page = context.pages[0]
    qr = page.locator(".login__type__container__scan__qrcode img")
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    save_path = os.path.join(desktop, f"wechat_qrcode_{int(time.time())}.png")
    await qr.screenshot(path=save_path)
```

2. 告知用户：**"二维码已截图到桌面（`wechat_qrcode_xxxxx.png`），请用微信扫码登录，完成后回复我"**
3. **停止执行，等待用户回复**（不做任何轮询或自动刷新）
4. 用户确认后，刷新页面，检查 URL 是否含 `cgi-bin/home`，确认后进入第四步

### 第四步：采集公众号文章资讯

登录成功后，使用 `scripts/crawl.py` 脚本执行采集流程：

```bash
python {SKILL_DIR}/scripts/crawl.py --account "公众号名称" --days N --output-json %TEMP%\zixun_articles.json
```

其中 `--days` 为往前推算的天数（近一周=7，近两周=14，近一个月=30）。

> **CDP 连接说明**：`crawl.py` 默认自动检测 WebSocket URL（`ws://localhost:9222/...`），无需手动传入 `--cdp-url`。脚本内部已处理 Windows 系统代理（HTTP_PROXY）干扰 localhost 的问题。Windows 用户仍需确保 `$env:PYTHONIOENCODING="utf-8"` 已设置。

脚本自动完成：搜索公众号 → 选择搜索结果 → 遍历文章列表（视觉扫描法 v3）→ 翻页 → 采集每篇文章的标题、来源、时间、链接。

> ⚠️ 与 gongzhonghao 不同，zixun 不提取文章正文，因此采集速度更快。

### 第五步：生成 Word 文档

使用 `scripts/generate_docx.py` 脚本将采集结果生成为表格形式的 Word 文档。**使用前必须先用 `read_file` 读取脚本内容确认接口。**

```bash
python {SKILL_DIR}/scripts/generate_docx.py --input-json %TEMP%\zixun_articles.json --output %USERPROFILE%\Desktop\资讯采集_公众号名称_YYYYMMDD.docx --account "公众号名称"
```

文档格式：
- **表格**：序号 | 标题 | 来源公众号 | 发布时间
- **链接汇总**：表格下方列出所有文章标题对应的链接
- 交替行背景色，表头蓝色白字

文件名格式：`资讯采集_公众号名称_YYYYMMDD.docx`，保存到桌面。

## 完整模式操作指南（视觉扫描法 v3）

> 脚本默认使用完整模式（`crawl_articles` 主流程），自动完成从搜索到翻页的全部操作。

### 核心流程（视觉扫描法 v3）

脚本使用「模拟鼠标操作」替代 DOM CSS 选择器，因为后者在微信公众号后台极不稳定。

#### 第一步：搜索公众号 & 选择搜索结果

脚本自动完成：打开超链接弹窗 → 点击「选择其他账号」 → 输入公众号名称 → 按回车搜索。

**选择搜索结果**（`select_first_search_result`）：
- 用 JS 遍历 DOM，找到文本完全匹配目标公众号名称的元素
- 优先匹配叶子节点（`children.length === 0`）
- 过滤条件：Y > 100（搜索框下方）、宽 > 50、高 20-100
- 获取坐标后 `mouse.click(x, y)` 直接点击

#### 第二步：定位搜索框 & 放大镜（阶段B）

**`find_search_area_anchor`**：定位「选择内容」旁边的搜索框和右侧🔍放大镜图标坐标。放大镜是所有扫描操作的起始参考点。

#### 第三步：先采集第一篇文章（阶段A0）

> ⚠️ **关键步骤**：先采集第一篇，再滚到底，避免滚到底再滚回来时漏掉第一篇。

1. 从放大镜位置 (`magnifier_y + 20`) 开始向下扫描
2. 用 `hover_and_find_view_button` 找到第一个【查看文章】按钮
3. 检查日期范围：
   - 早于起始日期 → 整个采集停止
   - 在范围内 → 点击进入，提取资讯信息，关闭返回
   - 将标题加入 `processed_titles`（后续扫描自动跳过）
4. 找不到按钮 → 跳过，继续后续流程

#### 第四步：JS 滚到底部加载完整列表（阶段A）

**`scroll_list_to_bottom_js`**（JS scrollTop，快速稳定）：
1. 用 `page.evaluate()` 找到可滚动容器
2. 直接设置 `scrollTop = scrollHeight - clientHeight`，一步到位
3. 轮询等待分页控件出现（列表加载完成），超时 5 秒
4. 然后 JS `scrollTop = 0` 回到顶部

#### 第五步：鼠标物理扫描采集文章（阶段C）

> 阶段A已回顶，从**视口最顶部（Y=0）**开始，鼠标沿放大镜 X 轴逐行下移扫描。

**`mouse_scan_for_view_button`**（鼠标物理扫描法）：
- 鼠标从 `scan_y` 开始，每 10px 向下移动一步
- 每步 `await asyncio.sleep(0.03)` 等待 hover 触发
- JS 检查鼠标附近（±30px）是否出现了 `textContent === '查看文章'` 的叶子节点
- 找到后返回按钮坐标 + 标题 + 日期
- 鼠标直接 `move()` 到按钮位置 → `click()` → 等待新标签页打开
- 提取资讯信息（标题、来源、时间、链接）后关闭标签页 → `mouse.wheel(0, 100)` 微滚 100px → `scan_y = 0` 从视口顶部重新扫描
- **扫不到时的处理**：`no_button_count += 1`，然后微滚 100px + JS 检测 `scrollTop` 位移
  - 位移 ≤ 5px（没滚动 = 到底了）→ 第一次到底时启动 15 秒倒计时，重置 `scan_y=0` 和 `no_button_count=0`，继续扫描；倒计时内再次扫不到则等超时自动跳出
  - 位移 > 5px（还在滚 = 没到底）→ 从 Y=0 重新扫描，重置到底计时
- **到底后 15 秒超时 → 本页处理完，进入翻页**
- **到底状态下 `no_button_count` 不触发退出**（只靠超时退出）

#### 第六步：翻页 — 使用【跳转】功能（阶段D）

不再点击 `>` 下一页按钮（经常找不到），改用【跳转】：
1. **直接复用阶段A拿到的分页信息**判断是否有下一页（不再重复滚到底轮询等待）
2. 一次快速 JS 滚到底部（0.5秒），让分页控件可见
3. JS 找到「跳转」文字旁边的 `<input>` 坐标
4. `mouse.click()` 点击输入框
5. `Ctrl+a` 全选 → 键盘输入页码数字
6. `find_text_by_ocr_fallback` 定位【跳转】按钮坐标 → `mouse.click()` 点击
7. 等待 2.5 秒 → JS `scrollTop = 0` 回顶 → 重新开始扫描（回到阶段B）

#### 第七步：提取文章资讯信息

文章页面打开后提取：
- 标题：`#activity-name` 或 `.rich_media_title`
- 公众号：`#js_name` 或 `.rich_media_meta_nickname a`
- 发布时间：正则从 meta 全文 → 正文全文 → JS `#publish_time` 三级策略提取（不再依赖 DOM 元素顺序）
- 链接：`article_page.url`

> ⚠️ **JSON 输出不含正文**，但爬取过程中会提取 `#js_content` 正文，用于辅助解析发布时间。等待时间为 1500ms（与 gongzhonghao 一致）。

### 发布时间解析策略（日期解析 v2）

不再依赖特定 DOM 元素位置（`#publish_time` 经常被作者名替代），改为从文本中正则搜索日期模式：

| 优先级 | 策略 | 说明 |
|--------|------|------|
| 1 | meta 全文正则搜索 | 获取所有 `.rich_media_meta_text` 元素文本拼接，用正则匹配日期（`YYYY年M月D日 HH:MM` → `YYYY年M月D日` → `YYYY-MM-DD` → `M月D日`） |
| 2 | 正文全文正则搜索 | 从 `#js_content` 正文中搜索日期模式（搜全文，不限字数） |
| 3 | JS `#publish_time` 兜底 | 用 JS 获取 `#publish_time` 的文本，用正则提取日期 |

### 已知问题

- **TargetClosedError**：点击搜索结果或「查看文章」后页面可能被导航销毁，已有 `try/except` 恢复逻辑
- **分页信息显示「第 0/64 页」**：`currentPage` 解析可能有误，但不影响翻页功能（兜底逻辑：已处理文章 > 0 就尝试翻页）
- **日期超出范围**：遇到早于起始日期的文章立即停止采集

## 关键注意事项

- **日期计算**：以运行当天中国大陆日期（UTC+8）为基准，**包含头尾两天**（start_date = N天前 00:00:00，end_date = 当天 23:59:59）
- **文章筛选**：只采集符合时间范围内的文章，遇到早于起始日期的文章立即停止
- **弹窗处理**：操作过程中如有弹窗遮挡，按 Escape 关闭
- **TargetClosedError**：点击搜索结果或「查看文章」后页面可能被导航销毁，`try/except` 包裹点击操作是预期行为
- **鼠标操作优先**：所有 UI 交互优先使用 `mouse.click(x, y)`，避免依赖 DOM 选择器
- **滚动方式**：阶段A（滚到底/回顶）使用 JS scrollTop（快速稳定）；阶段C微滚动使用 `mouse.wheel(0, 100)` + JS 检测 `scrollTop` 位移判断是否到底（位移 ≤5px 判定到底）
- **翻页策略**：使用【跳转】功能（JS 找输入框 → 键盘输入页码 → 点击【跳转】按钮），不点击 `>` 下一页按钮。翻页后用 JS `scrollTop=0` 回顶
- **扫描循环**：每次扫描从视口顶部（Y=0）开始。扫不到时微滚100px + JS检测scrollTop位移，位移≤5px判定到底，到底后启动15秒倒计时继续扫描，超时后翻页
- **第一篇文章**：每页开始扫描前，先从放大镜位置找到并采集第一篇（阶段A0），避免滚到底再滚回来时漏掉
- **已处理标题去重**：`processed_titles` 集合确保同一篇文章不会重复采集

## 按钮定位策略（重要）

`crawl.py` 采用「视觉扫描法 + 模拟鼠标操作」，彻底避免依赖固定 CSS class 导致的卡顿。

### 核心原则

**所有操作优先使用模拟鼠标**（`mouse.click(x, y)`），而非 DOM 选择器或 Playwright `.click()`。微信公众号后台的 class 名经常变化，不稳定。

### 核心工具函数

#### 视觉扫描法（文章列表遍历）

| 函数 | 用途 |
|------|------|
| `find_search_area_anchor(editor_page)` | 定位「选择内容」搜索框 + 右侧🔍放大镜图标坐标 |
| `hover_and_find_view_button(editor_page, start_y, x)` | 纯JS扫描【查看文章】按钮（阶段A0使用，返回按钮坐标+标题+日期） |
| `mouse_scan_for_view_button(editor_page, start_y, scan_x, step, max_y)` | **鼠标物理扫描法**（阶段C使用）：鼠标从Y顶部沿X轴逐行下移，hover触发【查看文章】显示，JS检测到后返回 |
| `scroll_list_to_bottom_js(editor_page)` | **JS scrollTop** 一步到底（阶段A主流程使用），轮询等待分页控件出现 |

#### 主循环阶段说明

| 阶段 | 名称 | 说明 |
|------|------|------|
| A0 | 先采集第一篇 | 从放大镜往下用JS找到第一篇【查看文章】→ 采集资讯 → 关闭返回，避免漏掉 |
| A | JS滚到底/回顶 | 用 JS scrollTop 一步到底加载完整列表，然后 scrollTop=0 回到顶部 |
| B | 定位搜索区域 | 找到「选择内容」搜索框 + 🔍放大镜坐标（扫描参考点） |
| C | 鼠标物理扫描采集 | 鼠标从视口顶部沿放大镜X轴逐行下移，hover触发【查看文章】→ 采集资讯。扫不到时微滚100px+JS检测scrollTop位移判断是否到底，到底后15秒超时翻页 |
| D | 翻页 | 用【跳转】功能跳到下一页，JS scrollTop=0 回顶后回到阶段B |

#### macOS 注意事项

- ⚠️ `mouse.wheel` 的 deltaY 方向与直觉相反：正值=视口向上，负值=视口向下
- ⚠️ 阶段A 滚到底/回顶改用 JS scrollTop（快速稳定），阶段C 微滚动用 `mouse.wheel(0, 100)`

## Windows 兼容性说明

本 skill 已全面支持 Windows + 影刀浏览器（ShadowBotBrowser）环境，主要修复点如下：

### 影刀浏览器路径

| 操作系统 | 影刀浏览器路径 |
|----------|--------------|
| macOS | `/Applications/影刀.app/Contents/Resources/app/node_modules/xbot-browser/lib/影刀浏览器.app/Contents/MacOS/影刀浏览器` |
| **Windows** | `C:\Program Files\ShadowBot\ShadowBot Browser\Application\ShadowBotBrowser.exe` |
| Linux | 不支持 |

Windows 下请确保影刀浏览器已安装到上述默认路径，或以 `--remote-debugging-port=9222` 参数手动启动。

### Windows 影刀浏览器启动方式

```powershell
# 关闭现有影刀浏览器
Stop-Process -Name "ShadowBotBrowser" -Force

# 以 CDP 调试模式启动
Start-Process "C:\Program Files\ShadowBot\ShadowBot Browser\Application\ShadowBotBrowser.exe" -ArgumentList "--remote-debugging-port=9222"
```

### CDP WebSocket 连接

Windows 下的 ShadowBotBrowser 不支持 HTTP 方式的 CDP 探测（会返回 502），**必须使用 WebSocket URL** 连接。`browser_check.py` 和 `crawl.py` 均已内置自动检测逻辑，会从 `http://localhost:9222/json/version` 获取 `webSocketDebuggerUrl` 并使用 `ws://` 前缀连接。

### 系统代理干扰（关键）

Windows 机器上若设置了 `HTTP_PROXY`/`HTTPS_PROXY` 环境变量（如代理软件 127.0.0.1:7890），Python 的 `urllib` 会将 `localhost` 请求也发往代理服务器，导致 CDP HTTP 探测返回 502。脚本内部已通过 `urllib.request.ProxyHandler({})` 强制绕过代理，无需手动修改 `no_proxy`。

### PowerShell 输出编码

PowerShell 默认编码（GBK）无法输出 emoji 等 Unicode 字符，会导致 `UnicodeEncodeError`。运行脚本前需设置：

```powershell
$env:PYTHONIOENCODING="utf-8"
```

或使用 Python 的 `-X utf8` 参数：
```powershell
python -X utf8 script.py
```

## 错误处理

- CDP 连接失败（502 / Unexpected status）→ 影刀浏览器未以 `--remote-debugging-port=9222` 参数启动，或 CDP 端口被占用；重启影刀浏览器后重试
- CDP 连接失败（502 via urllib）→ Windows 系统代理干扰 localhost；脚本已内置 ProxyHandler({}) 绕过，无需手动处理
- CDP 连接失败（connection refused）→ 影刀浏览器未启动或端口不是 9222
- 登录过期 → 重新截图二维码让用户扫码
- 未找到目标公众号 → 告知用户并确认公众号名称是否正确
- 指定时间范围内无文章 → 告知用户并询问是否扩大时间范围
- 文章信息提取失败 → 跳过该文章并记录，继续处理下一篇
