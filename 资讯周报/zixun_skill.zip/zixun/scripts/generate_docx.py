#!/usr/bin/env python3
"""
微信公众号资讯采集结果 - Word 文档生成器
将采集到的文章资讯（标题、来源公众号、发布时间、链接）生成为表格形式的 Word 文档。
"""

import json
import argparse
from datetime import datetime

try:
    from docx import Document
    from docx.shared import Pt, Cm, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
except ImportError:
    print("❌ 缺少 python-docx 库，正在安装...")
    import subprocess
    subprocess.check_call(["pip3", "install", "python-docx", "-q"])
    from docx import Document
    from docx.shared import Pt, Cm, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn


def set_cell_shading(cell, color_hex):
    """设置单元格背景色"""
    shading = cell._element.get_or_add_tcPr()
    shading_elem = shading.makeelement(qn('w:shd'), {
        qn('w:fill'): color_hex,
        qn('w:val'): 'clear'
    })
    shading.append(shading_elem)


def create_document(articles, output_path, account_name=""):
    """
    创建表格形式的 Word 文档

    Args:
        articles: 文章资讯列表
        output_path: 输出文件路径
        account_name: 公众号名称（用于文件名和标题）
    """
    doc = Document()

    # ========== 页面设置 ==========
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.left_margin = Cm(2)
    section.right_margin = Cm(2)
    section.top_margin = Cm(2)
    section.bottom_margin = Cm(2)

    # ========== 文档标题 ==========
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("微信公众号资讯采集报告")
    run.font.size = Pt(20)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)

    # 副标题
    if account_name:
        subtitle = doc.add_paragraph()
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitle.add_run(f"公众号：{account_name}")
        run.font.size = Pt(13)
        run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    # 生成日期和数量
    now = datetime.now()
    info = doc.add_paragraph()
    info.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = info.add_run(f"采集时间：{now.strftime('%Y年%m月%d日 %H:%M')}  |  共 {len(articles)} 条资讯")
    run.font.size = Pt(10)
    run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)

    # 分隔线
    doc.add_paragraph("─" * 60).alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ========== 表格 ==========
    if not articles:
        empty = doc.add_paragraph()
        empty.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = empty.add_run("（未采集到任何资讯）")
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)
    else:
        # 创建表格：4 列（序号、标题、来源公众号、发布时间）
        table = doc.add_table(rows=1 + len(articles), cols=4)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = 'Table Grid'

        # 设置列宽
        widths = [Cm(1.2), Cm(6.5), Cm(3.5), Cm(3.5)]
        for i, width in enumerate(widths):
            for cell in table.columns[i].cells:
                cell.width = width

        # 表头
        headers = ["序号", "标题", "来源公众号", "发布时间"]
        for i, header in enumerate(headers):
            cell = table.rows[0].cells[i]
            set_cell_shading(cell, "2B579A")
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(header)
            run.font.size = Pt(10)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        # 数据行
        for idx, article in enumerate(articles, 1):
            row = table.rows[idx]

            # 序号
            p = row.cells[0].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(str(idx))
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

            # 标题
            p = row.cells[1].paragraphs[0]
            run = p.add_run(article.get('title', '未知'))
            run.font.size = Pt(9)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

            # 来源公众号
            p = row.cells[2].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(article.get('account', '未知'))
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

            # 发布时间
            p = row.cells[3].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(article.get('publish_date', '未知'))
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

            # 交替行背景色
            if idx % 2 == 0:
                for cell in row.cells:
                    set_cell_shading(cell, "F2F6FC")

        # ========== 文章链接列表 ==========
        doc.add_paragraph()  # 空行
        link_title = doc.add_paragraph()
        run = link_title.add_run("🔗 文章链接汇总")
        run.font.size = Pt(12)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0x2B, 0x57, 0x9A)

        for idx, article in enumerate(articles, 1):
            p = doc.add_paragraph()
            run = p.add_run(f"{idx}. {article.get('title', '未知')}")
            run.font.size = Pt(9)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

            p2 = doc.add_paragraph()
            run = p2.add_run(f"   {article.get('url', '')}")
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(0x09, 0x6E, 0xD4)
            run.font.underline = True

    # ========== 保存文档 ==========
    doc.save(output_path)
    print(f"✅ Word 文档已保存到：{output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="微信公众号资讯 Word 文档生成器")
    parser.add_argument("--input-json", required=True, help="采集结果的 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 Word 文档路径")
    parser.add_argument("--account", default="", help="公众号名称")
    args = parser.parse_args()

    with open(args.input_json, "r", encoding="utf-8") as f:
        articles = json.load(f)

    create_document(articles, args.output, args.account)
