#!/usr/bin/env python3
"""
微信公众号资讯采集脚本（zixun skill）
通过 CDP 连接影刀浏览器，自动搜索公众号并采集指定时间范围内的文章资讯。
输出：标题、来源公众号、发布时间、链接（JSON 中不含正文，但爬取时会提取正文以辅助解析发布时间）。

核心策略（视觉扫描法 v3）：
- 使用「模拟鼠标操作」替代 DOM CSS 选择器（后者在微信公众号后台极不稳定）
- 每页先抓取第一篇文章（阶段A0），再滚到底加载完整列表，避免漏掉
- 日期范围包含头尾两天（start_date = N天前 00:00:00，end_date = 当天 23:59:59）
- 翻页使用【跳转】功能（输入页码 → 点击跳转按钮），不点击 > 下一页按钮
"""

import asyncio
import json
import argparse
import io
import base64
import time
from datetime import datetime, timedelta
from playwright.async_api import async_playwright

try:
    from PIL import Image, ImageChops
    import numpy as np
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("⚠️  Pillow/numpy 未安装，将降级为 DOM 定位模式。建议: pip3 install Pillow numpy")

# 中国大陆时区偏移
CHINA_OFFSET = 8


# ─────────────────────────────────────────────
#  截图 + 图像坐标定位工具
# ─────────────────────────────────────────────

async def screenshot_page(page):
    """对整个页面截图，返回 PIL Image"""
    if not HAS_PIL:
        return None
    png_bytes = await page.screenshot(full_page=False)
    return Image.open(io.BytesIO(png_bytes)).convert("RGB")


async def find_text_by_ocr_fallback(page, text: str):
    """
    通过 evaluate 在页面中找到包含指定文本的可见元素，
    返回其屏幕中心坐标 (x, y)，找不到则返回 None。
    这是不依赖固定选择器的通用文本定位方法。
    """
    result = await page.evaluate("""(text) => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return {
                x: Math.round(r.left + r.width / 2),
                y: Math.round(r.top + r.height / 2),
                rect: { left: r.left, top: r.top, width: r.width, height: r.height }
            };
        }
        // 遍历所有可见文本节点
        const walker = document.createTreeWalker(
            document.body, NodeFilter.SHOW_TEXT, null, false
        );
        let node;
        while ((node = walker.nextNode())) {
            if (node.textContent.trim() === text) {
                const el = node.parentElement;
                if (el && el.offsetParent !== null) {
                    const c = getCenter(el);
                    if (c) return c;
                }
            }
        }
        // 包含匹配（宽松模式）
        const all = document.querySelectorAll('*');
        for (const el of all) {
            if (el.children.length === 0 && el.textContent.trim().includes(text)
                && el.offsetParent !== null) {
                const c = getCenter(el);
                if (c) return c;
            }
        }
        return null;
    }""", text)
    return result


async def click_by_text(page, text: str, timeout_ms: int = 8000) -> bool:
    """
    通过文字内容定位元素并点击（不依赖选择器）。
    先尝试快速的 JS 坐标法，失败则截图模板匹配，最后降级到 Playwright locator。
    返回是否成功点击。
    """
    deadline = time.time() + timeout_ms / 1000

    while time.time() < deadline:
        # 方法1：JS 坐标定位
        pos = await find_text_by_ocr_fallback(page, text)
        if pos:
            await page.mouse.click(pos["x"], pos["y"])
            await page.wait_for_timeout(300)
            return True

        # 方法2：Playwright locator（作为后备）
        loc = page.locator(f"text={text}").first
        try:
            if await loc.count() > 0:
                box = await loc.bounding_box()
                if box:
                    cx = box["x"] + box["width"] / 2
                    cy = box["y"] + box["height"] / 2
                    await page.mouse.click(cx, cy)
                    await page.wait_for_timeout(300)
                    return True
        except Exception:
            pass

        await page.wait_for_timeout(400)

    print(f"  ⚠️ 未能找到文本元素: 「{text}」")
    return False


async def click_by_selector_or_text(page, selectors: list, fallback_text: str = None,
                                     timeout_ms: int = 8000) -> bool:
    """
    先尝试一组 CSS 选择器（取 bounding_box 后用鼠标点），
    全部失败后用文本定位作为最终兜底。
    """
    deadline = time.time() + timeout_ms / 1000

    while time.time() < deadline:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if await loc.count() > 0:
                    box = await loc.bounding_box()
                    if box and box["width"] > 0:
                        cx = box["x"] + box["width"] / 2
                        cy = box["y"] + box["height"] / 2
                        await page.mouse.click(cx, cy)
                        await page.wait_for_timeout(300)
                        return True
            except Exception:
                continue

        if fallback_text:
            pos = await find_text_by_ocr_fallback(page, fallback_text)
            if pos:
                await page.mouse.click(pos["x"], pos["y"])
                await page.wait_for_timeout(300)
                return True

        await page.wait_for_timeout(400)

    if fallback_text:
        print(f"  ⚠️ 所有选择器和文本定位均失败: 「{fallback_text}」")
    return False


async def find_input_and_fill(page, selectors: list, value: str,
                               placeholder_hint: str = None) -> bool:
    """
    在一组选择器中找到第一个可用的输入框，填入内容。
    兜底：通过 placeholder 文字定位 input。
    """
    for sel in selectors:
        try:
            loc = page.locator(sel).first
            if await loc.count() > 0 and await loc.is_visible():
                await loc.click()
                await loc.fill(value)
                return True
        except Exception:
            continue

    # 兜底：placeholder 定位
    if placeholder_hint:
        try:
            inp = page.locator(f"input[placeholder*='{placeholder_hint}']").first
            if await inp.count() > 0:
                await inp.click()
                await inp.fill(value)
                return True
        except Exception:
            pass

    # 最终兜底：找到任意可见 input 并填入
    try:
        inputs = page.locator("input:visible")
        n = await inputs.count()
        for i in range(n):
            try:
                inp = inputs.nth(i)
                box = await inp.bounding_box()
                if box and box["width"] > 50:
                    await inp.click()
                    await inp.fill(value)
                    return True
            except Exception:
                continue
    except Exception:
        pass

    return False


# ─────────────────────────────────────────────
#  时间工具
# ─────────────────────────────────────────────

def get_china_now():
    """获取当前中国大陆时间"""
    return datetime.utcnow() + timedelta(hours=CHINA_OFFSET)


def parse_date_range(days):
    """根据天数计算起止日期（包含头尾两天）"""
    now = get_china_now()
    # end_date: 当天 23:59:59，确保包含当天所有文章
    end_date = now.replace(hour=23, minute=59, second=59)
    # start_date: N 天前的 00:00:00，确保包含那一天的所有文章
    start_date = (now - timedelta(days=days)).replace(hour=0, minute=0, second=0)
    return start_date, end_date


def parse_article_date(date_text):
    """
    解析文章日期文本，返回 datetime 对象。
    支持格式：
    - "2026-03-30" / "2026年3月30日"
    - "3月30日"（默认当年）
    - "3天前" / "昨天" / "前天"
    - "2026-03-30 09:45"
    """
    if not date_text:
        return None
    now = get_china_now()
    for fmt in ["%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y年%m月%d日", "%Y年%m月%d日 %H:%M"]:
        try:
            return datetime.strptime(date_text.strip(), fmt)
        except ValueError:
            continue
    try:
        dt = datetime.strptime(date_text.strip(), "%m月%d日")
        return dt.replace(year=now.year)
    except ValueError:
        pass
    t = date_text.strip()
    if t == "昨天":
        return now - timedelta(days=1)
    if t == "前天":
        return now - timedelta(days=2)
    if "天前" in t:
        try:
            return now - timedelta(days=int(t.replace("天前", "")))
        except ValueError:
            pass
    return None


def is_in_date_range(article_date, start_date, end_date):
    if article_date is None:
        return True
    return start_date <= article_date <= end_date


# ─────────────────────────────────────────────
#  登录检查
# ─────────────────────────────────────────────

async def check_login(page) -> str:
    """
    检查登录状态，返回:
    - "logged_in"  : 已登录，可直接操作
    - "need_login" : 未登录，需扫码
    - "unknown"    : 无法判断，需导航后重试
    """
    try:
        url = page.url
        # URL 是最可靠的判断依据
        if "cgi-bin/home" in url or "cgi-bin/appmsg" in url or "cgi-bin/index" in url:
            return "logged_in"
        # 有二维码 → 未登录
        qrcode = page.locator(".login__type__container__scan__qrcode img")
        if await qrcode.count() > 0 and await qrcode.is_visible():
            return "need_login"
        # 有后台元素 → 已登录
        dashboard = page.locator(
            ".weui-desktop-account__nickname, .weui-desktop-sidebar, .main_bd"
        )
        if await dashboard.count() > 0:
            return "logged_in"
        return "unknown"
    except Exception:
        return "unknown"


async def screenshot_qrcode(page, save_path):
    """截图二维码并保存到桌面"""
    import time as _time
    # 优先截二维码元素
    qrcode = page.locator(".login__type__container__scan__qrcode img")
    if await qrcode.count() > 0:
        await qrcode.screenshot(path=save_path)
    else:
        # 兜底：截整个页面上半部分
        await page.screenshot(path=save_path, clip={"x": 0, "y": 0, "width": 800, "height": 600})


# ─────────────────────────────────────────────
#  导航：草稿箱 → 编辑器
# ─────────────────────────────────────────────

async def navigate_to_draft(page):
    """导航到草稿箱（用坐标点击，不依赖固定 class）"""
    clicked = await click_by_text(page, "内容管理", timeout_ms=6000)
    if not clicked:
        # 尝试直接导航
        await page.goto("https://mp.weixin.qq.com/cgi-bin/appmsg?t=media/appmsg_edit_v2&action=edit&type=10&token=&lang=zh_CN")
        return
    await page.wait_for_timeout(800)
    await click_by_text(page, "草稿箱", timeout_ms=6000)
    await page.wait_for_timeout(1200)


async def create_new_draft(context, current_page):
    """新建草稿并等待编辑器标签页打开"""
    # 点击"新的创作"
    try:
        ok = await click_by_text(current_page, "新的创作", timeout_ms=8000)
        if not ok:
            # 兜底：找带"新建"文字的按钮
            await click_by_selector_or_text(
                current_page,
                ["[class*='create-btn']", "[class*='new-btn']", ".weui-desktop-btn_primary"],
                fallback_text="新建"
            )
        await current_page.wait_for_timeout(800)
    except Exception as nav_err:
        # 点击后页面导航导致上下文销毁是正常现象
        print(f"  ℹ️ 点击新的创作后页面导航（预期行为）: {nav_err}")

    # 点击"写新文章"——先设置 page_promise，再点击
    try:
        page_promise = context.wait_for_event("page", timeout=30000)
        # 用 try/except 包裹点击，因为导航会销毁执行上下文
        try:
            ok2 = await click_by_text(current_page, "写新文章", timeout_ms=6000)
            if not ok2:
                await click_by_selector_or_text(
                    current_page,
                    ["li:visible .weui-desktop-list-item__text"],
                    fallback_text="写文章"
                )
        except Exception as click_err:
            # 点击后页面导航导致上下文销毁是正常现象
            print(f"  ℹ️ 点击写新文章后页面导航（预期行为）: {click_err}")

        new_page = await page_promise
        await new_page.wait_for_load_state("domcontentloaded", timeout=30000)
        return new_page
    except Exception as e:
        print(f"  ⚠️ 等待编辑器页面超时: {e}")
        # 回退：直接获取最新页面,不关闭任何页面
        await asyncio.sleep(2)
        pages = context.pages
        if len(pages) > 1:
            return pages[-1]
        # 如果没有新页面,返回当前页面(不报错,继续执行)
        return current_page


# ─────────────────────────────────────────────
#  超链接弹窗 & 搜索公众号
# ─────────────────────────────────────────────

async def open_hyperlink_dialog(new_page) -> bool:
    """
    点击编辑器工具栏上文字为「超链接」的按钮，打开超链接弹窗。

    工具栏上显示的是纯文字「超链接」，直接用文字定位即可，
    不需要依赖 class / title / aria-label 等属性。
    """
    await new_page.wait_for_timeout(1500)  # 等编辑器加载完毕

    # ── 策略1：JS 文字精确定位（最快，直接命中「超链接」文字按钮）──
    pos = await new_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
        }
        // 遍历所有叶子节点，找文字完全等于「超链接」的元素
        const all = document.querySelectorAll('*');
        for (const el of all) {
            if (el.children.length > 0) continue;           // 只找叶子节点
            if (el.offsetParent === null) continue;          // 排除隐藏元素
            const t = el.textContent.trim();
            if (t === '超链接') {
                const c = getCenter(el);
                if (c) return c;
            }
        }
        return null;
    }""")

    if pos:
        print(f"    🎯 「超链接」按钮坐标: ({pos['x']}, {pos['y']})")
        await new_page.mouse.click(pos["x"], pos["y"])
        await new_page.wait_for_timeout(800)
        return True

    # ── 策略2：Playwright text locator + bounding_box ──
    print("    🔄 JS定位未命中，尝试 Playwright text locator...")
    loc = new_page.get_by_text("超链接", exact=True).first
    try:
        if await loc.count() > 0:
            box = await loc.bounding_box()
            if box:
                cx = box["x"] + box["width"] / 2
                cy = box["y"] + box["height"] / 2
                await new_page.mouse.click(cx, cy)
                await new_page.wait_for_timeout(800)
                return True
    except Exception:
        pass

    # ── 策略3：键盘快捷键 Cmd+K（兜底）──
    print("    ⌨️  尝试键盘快捷键 Cmd+K...")
    try:
        editor = new_page.locator(
            ".ql-editor, [contenteditable='true'], #ueditor_0, .rich-textarea"
        ).first
        if await editor.count() > 0 and await editor.is_visible():
            await editor.click(timeout=3000)
        else:
            viewport = new_page.viewport_size or {"width": 1280, "height": 800}
            await new_page.mouse.click(viewport["width"] // 2, viewport["height"] // 2)
    except Exception:
        viewport = new_page.viewport_size or {"width": 1280, "height": 800}
        await new_page.mouse.click(viewport["width"] // 2, viewport["height"] // 2)
    await new_page.wait_for_timeout(300)
    await new_page.keyboard.press("Meta+k")
    await new_page.wait_for_timeout(800)
    dlg = new_page.locator("[class*='dialog'], [class*='modal'], [class*='popup']")
    if await dlg.count() > 0:
        return True

    print("    ❌ 三种策略均未能打开超链接弹窗")
    return False


async def click_select_other_account(new_page) -> bool:
    """点击【选择其他账号】按钮"""
    await new_page.wait_for_timeout(800)
    
    # 策略1：JS 坐标文本定位
    pos = await new_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }
        // 找文字完全等于「选择其他账号」的元素
        const all = Array.from(document.querySelectorAll('*'));
        for (const el of all) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '选择其他账号') {
                const c = getCenter(el);
                if (c) return c;
            }
        }
        return null;
    }""")
    
    if pos:
        print(f"    🎯 「选择其他账号」坐标: ({pos['x']}, {pos['y']})")
        await new_page.mouse.click(pos["x"], pos["y"])
        await new_page.wait_for_timeout(1000)
        return True
    
    # 策略2：Playwright text locator
    try:
        loc = new_page.get_by_text("选择其他账号", exact=True).first
        if await loc.count() > 0:
            box = await loc.bounding_box()
            if box:
                cx = box["x"] + box["width"] / 2
                cy = box["y"] + box["height"] / 2
                await new_page.mouse.click(cx, cy)
                await new_page.wait_for_timeout(1000)
                return True
    except Exception:
        pass
    
    print("  ⚠️ 未找到「选择其他账号」按钮")
    return False


async def click_search_icon(new_page) -> bool:
    """点击搜索框右侧的🔍图标"""
    await new_page.wait_for_timeout(500)
    
    # 策略1：找搜索图标（通常是一个 button 或 svg 图标）
    pos = await new_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }
        // 找搜索按钮（在输入框右侧）
        const buttons = document.querySelectorAll('button, [class*="search"], [class*="icon"]');
        for (const btn of buttons) {
            if (btn.offsetParent === null) continue;
            // 找包含搜索图标或搜索文字的
            const hasSearchIcon = btn.querySelector('svg, [class*="icon"], i') !== null;
            const text = btn.textContent.trim();
            if (hasSearchIcon || text.includes('搜索') || text === '') {
                const c = getCenter(btn);
                if (c && c.x > 400) {  // 搜索图标通常在右侧
                    return c;
                }
            }
        }
        // 兜底：找所有可见的 button，点击最右侧的
        const allBtns = Array.from(document.querySelectorAll('button, [role="button"]'))
            .filter(b => b.offsetParent !== null);
        if (allBtns.length > 0) {
            // 按 x 坐标排序，找最右边的
            allBtns.sort((a, b) => {
                const ra = a.getBoundingClientRect();
                const rb = b.getBoundingClientRect();
                return rb.left - ra.left;
            });
            return getCenter(allBtns[0]);
        }
        return null;
    }""")
    
    if pos:
        print(f"    🎯 「搜索图标」坐标: ({pos['x']}, {pos['y']})")
        await new_page.mouse.click(pos["x"], pos["y"])
        await new_page.wait_for_timeout(1500)
        return True
    
    print("  ⚠️ 未找到搜索图标，尝试按回车")
    await new_page.keyboard.press("Enter")
    await new_page.wait_for_timeout(1500)
    return True


async def select_first_search_result(new_page, account_name: str = "") -> bool:
    """
    选择搜索结果：找到搜索框右侧的放大镜🔍，从放大镜往下扫描，
    找到第一个「公众号」文字标签并点击。

    不再依赖精确匹配公众号名称，而是点击搜索结果中的「公众号」类型标签。
    """
    await new_page.wait_for_timeout(1500)

    # 先用 JS 找到搜索框旁边的放大镜图标坐标
    magnifier_pos = await new_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }

        // 找搜索框 input
        const allEls = Array.from(document.querySelectorAll('*'));
        let searchInput = null;

        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '选择内容' || t === '公众号') {
                let container = el.parentElement;
                for (let depth = 0; depth < 5 && container; depth++) {
                    const input = container.querySelector('input');
                    if (input && input.offsetParent !== null) {
                        searchInput = input;
                        break;
                    }
                    container = container.parentElement;
                }
                if (searchInput) break;
            }
        }

        // 兜底：找可见的 input
        if (!searchInput) {
            const inputs = document.querySelectorAll('input[type="text"], input:not([type])');
            for (const inp of inputs) {
                if (inp.offsetParent === null) continue;
                const rect = inp.getBoundingClientRect();
                if (rect.width > 100 && rect.top > 50) {
                    searchInput = inp;
                    break;
                }
            }
        }

        if (!searchInput) return null;

        const inputRect = searchInput.getBoundingClientRect();

        // 找放大镜：搜索框右侧的小图标
        let magnifier = null;
        let parent = searchInput.parentElement;
        for (let depth = 0; depth < 4 && parent; depth++) {
            const siblings = parent.querySelectorAll('button, [class*="icon"], [class*="btn"], svg, i, [class*="search"]');
            for (const sib of siblings) {
                if (sib === searchInput || sib.offsetParent === null) continue;
                const sibRect = sib.getBoundingClientRect();
                const yOverlap = Math.abs(sibRect.top - inputRect.top) < inputRect.height + 10;
                const xAfter = sibRect.left >= inputRect.left;
                const smallEnough = sibRect.width < 60 && sibRect.height < 60;
                if (yOverlap && xAfter && smallEnough) {
                    const c = getCenter(sib);
                    if (c) { magnifier = c; break; }
                }
            }
            if (magnifier) break;
            parent = parent.parentElement;
        }

        // 兜底：搜索框右边缘
        if (!magnifier) {
            magnifier = {
                x: Math.round(inputRect.right - 10),
                y: Math.round(inputRect.top + inputRect.height / 2)
            };
        }

        return { magnifier, inputRight: Math.round(inputRect.right) };
    }""")

    if not magnifier_pos:
        print("  ⚠️ 无法定位搜索框/放大镜")
        return False

    mag = magnifier_pos["magnifier"]
    scan_x = mag["x"]
    scan_y = mag["y"] + 20  # 从放大镜下方开始扫描

    print(f"    🔍 放大镜坐标: ({mag['x']}, {mag['y']})，从 Y={scan_y} 开始向下扫描「公众号」")

    # 鼠标从放大镜下方逐行下移，hover 触发下拉结果
    # 找到第一个包含「公众号」文字的可见元素并点击
    result = await new_page.evaluate("""(params) => {
        const { startX, startY, step, maxY } = params;

        // 找到第一个「公众号」文字元素（叶子节点优先）
        const allEls = Array.from(document.querySelectorAll('*'));
        const candidates = [];

        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '公众号' && el.children.length === 0) {
                const rect = el.getBoundingClientRect();
                if (rect.top >= startY && rect.top <= maxY && rect.width > 10) {
                    const cx = Math.round(rect.left + rect.width / 2);
                    const cy = Math.round(rect.top + rect.height / 2);
                    candidates.push({ x: cx, y: cy, elTop: rect.top, text: t });
                }
            }
        }

        // 按垂直位置排序，选最上面的一个（即第一个搜索结果的类型标签）
        candidates.sort((a, b) => a.elTop - b.elTop);

        if (candidates.length === 0) return null;

        return candidates[0];
    }""", {"startX": scan_x, "startY": scan_y, "step": 10, "maxY": 800})

    if result:
        print(f"    🎯 找到「公众号」标签坐标: ({result['x']}, {result['y']})")
        await new_page.mouse.click(result["x"], result["y"])
        await new_page.wait_for_timeout(2000)
        return True

    # 兜底：尝试鼠标物理扫描法（逐行 hover）
    import asyncio
    viewport = new_page.viewport_size or {"width": 1280, "height": 800}
    current_y = scan_y
    max_y = viewport["height"] - 20
    found = False

    while current_y <= max_y and not found:
        await new_page.mouse.move(scan_x, current_y)
        await asyncio.sleep(0.05)

        btn_result = await new_page.evaluate("""(scanY) => {
            const allEls = Array.from(document.querySelectorAll('*'));
            for (const el of allEls) {
                if (el.offsetParent === null) continue;
                const t = el.textContent.trim();
                if (t === '公众号' && el.children.length === 0) {
                    const rect = el.getBoundingClientRect();
                    if (rect.top >= scanY - 30 && rect.top <= scanY + 30) {
                        const cx = Math.round(rect.left + rect.width / 2);
                        const cy = Math.round(rect.top + rect.height / 2);
                        return { x: cx, y: cy };
                    }
                }
            }
            return null;
        }""", current_y)

        if btn_result:
            print(f"    🎯 鼠标扫描找到「公众号」标签坐标: ({btn_result['x']}, {btn_result['y']})")
            await new_page.mouse.click(btn_result["x"], btn_result["y"])
            await new_page.wait_for_timeout(2000)
            found = True

        current_y += 10

    if not found:
        print(f"  ⚠️ 从放大镜下方未找到「公众号」标签")
    return found


async def search_account(new_page, account_name, stop_before_dropdown: bool = False) -> dict:
    """
    在超链接弹窗中搜索公众号
    
    Args:
        new_page: 编辑器页面
        account_name: 公众号名称
        stop_before_dropdown: 如果为 True，在搜索完成后停止，不点击下拉框
                            （由 Agent 接手处理下拉框交互）
    
    Returns:
        dict: 包含状态信息
            - status: "ready_for_agent" 表示已准备好让 Agent 接手
            - status: "completed" 表示脚本已完成全部操作
    """
    # 打开超链接弹窗
    opened = await open_hyperlink_dialog(new_page)
    if not opened:
        print("  ⚠️ 超链接弹窗未打开，尝试继续...")

    await new_page.wait_for_timeout(800)

    # 点击「选择其他账号」
    clicked = await click_select_other_account(new_page)
    if not clicked:
        print("  ⚠️ 未能点击「选择其他账号」，尝试继续...")

    # 填写搜索框
    ok = await find_input_and_fill(
        new_page,
        [
            "input[placeholder*='账号名称']",
            "input[placeholder*='公众号']",
            "input[placeholder*='搜索']",
            "input[type='text']",
            "[class*='search'] input",
            "[class*='Search'] input"
        ],
        account_name,
        placeholder_hint="账号"
    )
    if not ok:
        print(f"  ⚠️ 未找到搜索框，尝试强制点击可见 input")
    else:
        print(f"  ✅ 已在搜索框输入: {account_name}")

    # 按回车键搜索
    await new_page.keyboard.press("Enter")
    await new_page.wait_for_timeout(1500)
    
    # 如果是 Agent 模式，在这里停止，返回状态
    if stop_before_dropdown:
        print("\n" + "=" * 60)
        print("🎯 脚本已完成搜索操作，准备交给 Agent 接手")
        print("=" * 60)
        print(f"📌 当前状态：")
        print(f"   - 搜索框已输入：{account_name}")
        print(f"   - 已按回车搜索")
        print(f"   - 下拉框应该已显示搜索结果")
        print(f"\n👉 Agent 请执行以下操作：")
        print(f"   1. 点击下拉框中的第一个公众号（搜索结果）")
        print(f"   2. 获取文章列表")
        print(f"   3. 对每篇文章：hover → 点击「查看文章」→ 提取内容")
        print("=" * 60)
        return {"status": "ready_for_agent", "account_name": account_name}
    
    # 原有逻辑：脚本完成全部操作
    await select_first_search_result(new_page, account_name)
    return {"status": "completed"}


# ─────────────────────────────────────────────
#  文章列表 & 内容提取（新策略：视觉扫描法）
# ─────────────────────────────────────────────

async def find_search_area_anchor(editor_page):
    """
    定位搜索区域的关键锚点：

    在文章列表弹窗中，找到「选择内容」旁边的搜索框，
    然后找到搜索框最右侧的「放大镜🔍」图标。

    返回:
        {
            search_box: {x, y, width, height},  // 搜索框位置
            magnifier: {x, y},                  // 放大镜图标中心坐标
        }
        如果找不到返回 None
    """
    result = await editor_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }
        function getRect(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left), y: Math.round(r.top), width: Math.round(r.width), height: Math.round(r.height) };
        }

        // 策略1：找到「选择内容」文字，其旁边的 input 就是搜索框
        const allEls = Array.from(document.querySelectorAll('*'));
        let searchInput = null;
        let selectContentEl = null;

        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '选择内容') {
                selectContentEl = el;
                break;
            }
        }

        if (selectContentEl) {
            // 在同一父容器中搜索 input
            let container = selectContentEl.parentElement;
            for (let depth = 0; depth < 5 && container; depth++) {
                const input = container.querySelector('input');
                if (input && input.offsetParent !== null) {
                    searchInput = input;
                    break;
                }
                container = container.parentElement;
            }
        }

        // 策略2：兜底 - 直接找可见的 input（在弹窗中的）
        if (!searchInput) {
            const inputs = document.querySelectorAll('input[type="text"], input:not([type])');
            // 过滤掉太小的 input 和在主编辑区的 input
            for (const inp of inputs) {
                if (inp.offsetParent === null) continue;
                const rect = inp.getBoundingClientRect();
                if (rect.width > 100 && rect.top > 50 && rect.left > 50) {
                    searchInput = inp;
                    break;
                }
            }
        }

        if (!searchInput) return null;

        const searchBoxRect = getRect(searchInput);
        if (!searchBoxRect) return null;

        // 找放大镜图标：搜索框右侧的按钮/图标
        // 通常是一个紧挨着 input 的按钮或 svg
        let magnifierCenter = null;

        // 在 input 的父容器中找紧邻的按钮
        let parent = searchInput.parentElement;
        for (let depth = 0; depth < 4 && parent; depth++) {
            const siblings = parent.querySelectorAll('button, [class*="icon"], [class*="btn"], svg, i');
            for (const sib of siblings) {
                if (sib.offsetParent === null) continue;
                const sibRect = sib.getBoundingClientRect();
                // 放大镜应该在搜索框右侧，Y坐标相近
                const yOverlap = Math.abs(sibRect.top - searchBoxRect.top) < searchBoxRect.height;
                const xAfter = sibRect.left >= searchBoxRect.left;
                const smallEnough = sibRect.width < 60 && sibRect.height < 60;
                if (yOverlap && xAfter && smallEnough) {
                    const c = getCenter(sib);
                    if (c) {
                        magnifierCenter = c;
                        break;
                    }
                }
            }
            if (magnifierCenter) break;
            parent = parent.parentElement;
        }

        // 兜底：如果没有找到放大镜图标，就用搜索框右边缘作为起始点
        if (!magnifierCenter) {
            magnifierCenter = {
                x: searchBoxRect.x + searchBoxRect.width - 10,
                y: searchBoxRect.y + Math.round(searchBoxRect.height / 2)
            };
        }

        return {
            search_box: searchBoxRect,
            magnifier: magnifierCenter
        };
    }""")

    if result:
        print(f"    📍 搜索框位置: ({result['search_box']['x']}, {result['search_box']['y']}) "
              f"{result['search_box']['width']}x{result['search_box']['height']}")
        print(f"    🔍 放大镜位置: ({result['magnifier']['x']}, {result['magnifier']['y']})")
    return result


async def scan_for_view_article_buttons(editor_page, start_y, magnifier_x):
    """
    从指定 Y 坐标开始向下扫描，找到所有【查看文章】按钮的位置。

    使用页面滚动 + 视觉扫描的方式，模拟人工操作。

    Args:
        editor_page: 编辑器页面
        start_y: 开始扫描的 Y 坐标
        magnifier_x: 放大镜的 X 坐标（用于保持水平对齐）

    Returns:
        list: 按从上到下排列的【查看文章】按钮坐标列表 [{x, y, index}]
    """
    buttons = []

    # 获取当前视口高度
    viewport = editor_page.viewport_size or {"width": 1280, "height": 800}
    viewport_height = viewport["height"]

    # 获取当前滚动位置
    scroll_info = await editor_page.evaluate("""() => {
        // 检查弹窗容器是否有滚动
        const scrollable = document.querySelector('[class*="scroll"], [class*="list"]');
        if (scrollable && scrollable.scrollHeight > scrollable.clientHeight) {
            return {
                type: 'element',
                scrollTop: scrollable.scrollTop,
                scrollHeight: scrollable.scrollHeight,
                clientHeight: scrollable.clientHeight
            };
        }
        return {
            type: 'window',
            scrollTop: window.scrollY,
            scrollHeight: document.body.scrollHeight,
            clientHeight: window.innerHeight
        };
    }""")

    # 在当前可见区域查找【查看文章】按钮
    result = await editor_page.evaluate("""(params) => {
        const { startY } = params;
        const buttons = [];

        const allEls = Array.from(document.querySelectorAll('*'));
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '查看文章') {
                const rect = el.getBoundingClientRect();
                // 只找在 start_y 下方的按钮
                if (rect.top > startY) {
                    buttons.push({
                        x: Math.round(rect.left + rect.width / 2),
                        y: Math.round(rect.top + rect.height / 2),
                        screenY: Math.round(rect.top)  // 相对于视口的位置
                    });
                }
            }
        }

        // 按 Y 坐标排序
        buttons.sort((a, b) => a.screenY - b.screenY);
        return buttons;
    }""", {"startY": start_y})

    if result:
        buttons = result
        print(f"    🔍 找到 {len(buttons)} 个【查看文章】按钮")

    return buttons


async def get_current_page_articles_info(editor_page):
    """
    获取当前页面显示的文章信息（标题+日期），用于判断日期是否在范围内。

    不做点击操作，只读取当前可见的文章信息。

    Returns:
        dict: {
            articles: [{title, date, view_btn_coords}],
            pagination: {currentPage, totalPages, hasNext},
            next_button_coords: {x, y} or None,
            page_end_reached: bool  // 是否已到底
        }
    """
    result = await editor_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }

        const allEls = Array.from(document.querySelectorAll('*'));
        const articles = [];
        const viewBtns = [];

        // 收集所有【查看文章】按钮
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            if (el.textContent.trim() === '查看文章' && el.children.length === 0) {
                const rect = el.getBoundingClientRect();
                const c = getCenter(el);
                if (c && rect.top > 100) {
                    viewBtns.push({ ...c, rect });
                }
            }
        }

        // 收集日期格式的元素
        const dateEls = [];
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const text = el.textContent.trim();
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;

            const dateMatch = text.match(/(\\d{4}-\\d{2}-\\d{2})/);
            if (dateMatch && rect.top > 100 && rect.height < 50) {
                dateEls.push({ el, date: dateMatch[1], rect, text });
            }
        }

        // 为每个【查看文章】按钮关联文章信息
        viewBtns.sort((a, b) => a.rect.top - b.rect.top);
        dateEls.sort((a, b) => a.rect.top - b.rect.top);

        for (const btn of viewBtns) {
            // 找到与这个按钮最接近的日期元素（通常在同一行或上方）
            let bestDate = null;
            let bestTitle = '';
            let minDist = Infinity;

            for (const de of dateEls) {
                const dist = Math.abs(de.rect.top - btn.rect.top);
                // 日期应该在按钮上方不远处（同一行或上一行）
                if (dist < 80 && dist < minDist) {
                    minDist = dist;
                    bestDate = de.date;

                    // 尝试找标题：在日期元素的兄弟元素中找
                    let prevEl = de.el.previousElementSibling;
                    while (prevEl) {
                        const prevText = prevEl.textContent.trim();
                        if (prevText && prevText.length > 5 && !prevText.match(/\\d{4}-\\d{2}-\\d{2}/)) {
                            bestTitle = prevText;
                            break;
                        }
                        prevEl = prevEl.previousElementSibling;
                    }

                    if (!bestTitle) {
                        const parent = de.el.parentElement;
                        if (parent) {
                            const parentText = parent.textContent.trim();
                            const dateIndex = parentText.indexOf(de.date);
                            if (dateIndex > 0) {
                                bestTitle = parentText.substring(0, dateIndex).trim();
                            }
                        }
                    }

                    if (!bestTitle) {
                        bestTitle = de.text.replace(de.date, '').trim();
                    }
                }
            }

            // 过滤无效标题
            const editorKeywords = [
                '本地上传', '从图片库选择', '微信扫码上传', 'AI 配图',
                '地理位置', '视频号', '账号名片', '问答', '礼物',
                '收入变现', '广告程序化广告', '互选广告', '带货小店',
                '返佣商品', '小程序', '文档导入', '请在这里输入标题',
                '原创', '请输入作者', '从正文选择', '可选视频封面',
                '合集', '未添加', '原文链接', '创作来源', '平台推荐',
                '已开启', '完成', '选择其他账号', '输入链接', '跳转'
            ];
            const isEditorElement = editorKeywords.some(kw => bestTitle.includes(kw));
            if (isEditorElement) continue;
            if (!bestTitle || bestTitle.length < 5 || bestTitle.length > 200) continue;

            articles.push({
                title: bestTitle,
                date: bestDate,
                view_btn_x: btn.x,
                view_btn_y: btn.y
            });
        }

        // 去重
        const seen = new Set();
        const unique = articles.filter(a => {
            if (seen.has(a.title)) return false;
            seen.add(a.title);
            return true;
        });

        // 分页信息
        let pagination = { hasNext: false, currentPage: 1, totalPages: 1 };
        const bodyText = document.body.textContent;
        const pMatch = bodyText.match(/(\\d+)\\s*\\/\\s*(\\d+)/);
        if (pMatch) {
            pagination.currentPage = parseInt(pMatch[1]);
            pagination.totalPages = parseInt(pMatch[2]);
            pagination.hasNext = pagination.currentPage < pagination.totalPages;
        }

        // 下一页按钮
        let nextBtn = null;
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '>' || t === '›' || t === '»' || el.getAttribute('aria-label') === '下一页') {
                const rect = el.getBoundingClientRect();
                if (rect.top > window.innerHeight * 0.6 && rect.width < 60 && rect.height < 40) {
                    nextBtn = { x: Math.round(rect.left + rect.width/2), y: Math.round(rect.top + rect.height/2) };
                    break;
                }
            }
        }

        // 是否到底了（没有更多【查看文章】按钮）
        const pageEnd = viewBtns.length === 0;

        return {
            articles: unique,
            pagination,
            next_button: nextBtn,
            page_end: pageEnd
        };
    }""")

    return result or {"articles": [], "pagination": {"hasNext": False}, "next_button": None, "page_end": True}


def _is_valid_date(text):
    """验证文本是否包含日期特征（如 2026-03-28、03月28日、2026年3月28日 等）"""
    if not text:
        return False
    import re
    # 匹配常见日期格式：YYYY-MM-DD、YYYY/MM/DD、YYYY年M月D日、M月D日、MM-DD 等
    patterns = [
        r'\d{4}[-/]\d{1,2}[-/]\d{1,2}',   # 2026-03-28、2026/03/28
        r'\d{4}年\d{1,2}月\d{1,2}日',      # 2026年3月28日
        r'\d{1,2}月\d{1,2}日',             # 3月28日
        r'\d{4}-\d{2}-\d{2}',             # 2026-03-28
    ]
    return any(re.search(p, text) for p in patterns)


async def extract_article_content(article_page):
    """提取文章完整内容（与 gongzhonghao 统一），包含标题、来源公众号、发布时间、链接、正文"""
    import re
    await article_page.wait_for_load_state("domcontentloaded")
    await article_page.wait_for_timeout(1500)

    title_el = article_page.locator("#activity-name, .rich_media_title").first
    title = await title_el.inner_text() if await title_el.count() > 0 else ""

    account_el = article_page.locator("#js_name, .rich_media_meta_nickname a").first
    account = await account_el.inner_text() if await account_el.count() > 0 else ""

    # 发布时间提取：不再依赖特定DOM元素位置，而是从文本中搜索日期模式
    # 微信文章的 meta 区域通常包含：作者名、日期、公众号名等，元素顺序不固定
    # 所以直接获取所有 meta 文本，用正则匹配日期

    def _extract_date_from_text(text):
        """从文本中提取第一个日期字符串"""
        if not text:
            return ""
        # 优先匹配 YYYY年M月D日 HH:MM（最完整的格式）
        m = re.search(r'(\d{4}年\d{1,2}月\d{1,2}日\s*\d{1,2}:\d{2})', text)
        if m:
            return m.group(1).strip()
        # 匹配 YYYY年M月D日
        m = re.search(r'(\d{4}年\d{1,2}月\d{1,2}日)', text)
        if m:
            return m.group(1)
        # 匹配 YYYY-MM-DD HH:MM
        m = re.search(r'(\d{4}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2})', text)
        if m:
            return m.group(1)
        # 匹配 YYYY-MM-DD
        m = re.search(r'(\d{4}-\d{1,2}-\d{1,2})', text)
        if m:
            return m.group(1)
        # 匹配 M月D日 HH:MM（当年，无年份）
        m = re.search(r'(\d{1,2}月\d{1,2}日\s*\d{1,2}:\d{2})', text)
        if m:
            return m.group(1).strip()
        # 匹配 M月D日（当年）
        m = re.search(r'(\d{1,2}月\d{1,2}日)', text)
        if m:
            return m.group(1)
        return ""

    pub_date = ""

    # 策略1: 从 meta 区域所有 .rich_media_meta_text 元素文本中搜索日期
    meta_els = article_page.locator(".rich_media_meta_text")
    meta_count = await meta_els.count()
    all_meta_text = ""
    for idx in range(meta_count):
        text = (await meta_els.nth(idx).inner_text()).strip()
        all_meta_text += text + " "
    pub_date = _extract_date_from_text(all_meta_text)

    # 策略2: 如果 meta 区域没找到，从正文中搜索日期（不限500字，搜全文）
    content_el = article_page.locator("#js_content").first
    content = await content_el.inner_text() if await content_el.count() > 0 else ""
    if not pub_date and content:
        pub_date = _extract_date_from_text(content)

    # 策略3: 兜底 - 用 JS 获取 #publish_time 的文本，如果包含日期就提取
    if not pub_date:
        raw_publish = await article_page.evaluate("""() => {
            const el = document.getElementById('publish_time');
            return el ? el.innerText.trim() : '';
        }""")
        pub_date = _extract_date_from_text(raw_publish) if raw_publish else ""

    url = article_page.url

    return {
        "title": title.strip(),
        "account": account.strip(),
        "publish_date": pub_date.strip(),
        "url": url,
        "content": content.strip()
    }


async def click_view_article_button(editor_page, btn_x, btn_y):
    """
    直接点击【查看文章】按钮，等待文章页面打开。

    Args:
        editor_page: 编辑器页面
        btn_x, btn_y: 【查看文章】按钮的中心坐标

    Returns:
        article_page: 打开的文章页面对象，失败返回 None
    """
    context = editor_page.context

    print(f"    🖱️ 鼠标移到「查看文章」: ({btn_x}, {btn_y})")
    # 先移动鼠标到按钮上方（模拟 hover，确保按钮可见）
    await editor_page.mouse.move(btn_x, btn_y)
    await editor_page.wait_for_timeout(300)

    print(f"    👆 点击「查看文章」")
    # 记录点击前的页面数量
    pages_before = set(id(p) for p in context.pages)

    # 点击，等待新页面打开
    page_promise = context.wait_for_event("page", timeout=15000)
    try:
        await editor_page.mouse.click(btn_x, btn_y)
    except Exception as e:
        print(f"    ⚠️ 点击失败: {e}")
        return None

    try:
        article_page = await page_promise
        await article_page.wait_for_load_state("domcontentloaded", timeout=15000)
        # 验证是否是文章页面（URL 包含 /s/ 才是文章）
        if '/s/' in article_page.url:
            print(f"    ✅ 文章页面已打开")
            return article_page
        else:
            # 打开的不是文章页面（可能是编辑器页面），关闭它
            print(f"    ⚠️ 打开的不是文章页面 ({article_page.url[:60]}...)，关闭")
            try:
                await article_page.close()
            except Exception:
                pass
            return None
    except Exception as e:
        print(f"    ⚠️ 等待文章页面超时: {e}")
        # 检查是否有新页面打开
        pages_after = context.pages
        for p in reversed(pages_after):
            if id(p) not in pages_before and p != editor_page:
                if '/s/' in p.url:
                    print(f"    ✅ 找到已打开的文章页面")
                    return p
                else:
                    # 不是文章页面，关闭
                    print(f"    ⚠️ 打开了非文章页面 ({p.url[:60]}...)，关闭")
                    try:
                        await p.close()
                    except Exception:
                        pass
        return None


async def scroll_list_to_bottom_js(editor_page, max_duration_ms=5000):
    """
    用JS直接把列表容器scrollTop设到底部（加载完整列表），不使用鼠标拖拽。

    原理：JS设 scrollTop = scrollHeight - clientHeight，一步到位。
    然后轮询等待分页控件出现（列表加载完成）。

    Returns:
        dict: { pagination, next_button }
    """
    # 先用JS一步到底
    await editor_page.evaluate("""() => {
        const scrollableEls = document.querySelectorAll(
            '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
        );
        for (const el of scrollableEls) {
            if (el.scrollHeight > el.clientHeight + 10) {
                el.scrollTop = el.scrollHeight - el.clientHeight;
                return;
            }
        }
        window.scrollTo(0, document.body.scrollHeight);
    }""")
    print(f"    📍 JS scrollTop 设到底部")

    # 等待分页控件出现
    start_time = time.time()
    max_seconds = max_duration_ms / 1000
    pagination_info = None
    next_btn_info = None

    while time.time() - start_time < max_seconds:
        await asyncio.sleep(0.5)

        result = await editor_page.evaluate("""() => {
            function getCenter(el) {
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return null;
                return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
            }

            // 检查分页信息
            const bodyText = document.body.textContent;
            const pMatch = bodyText.match(/(\\d+)\\s*\\/\\s*(\\d+)/);
            let pagination = null;
            if (pMatch) {
                const cur = parseInt(pMatch[1]);
                const total = parseInt(pMatch[2]);
                pagination = { currentPage: cur, totalPages: total, hasNext: cur < total };
            }

            // 检查是否真正到底
            const scrollableEls = document.querySelectorAll(
                '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
            );
            let isAtBottom = false;
            for (const el of scrollableEls) {
                if (el.scrollHeight > el.clientHeight + 10) {
                    isAtBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 5;
                    break;
                }
            }

            return { pagination, isAtBottom };
        }""")

        pagination_info = result.get("pagination")
        is_at_bottom = result.get("isAtBottom", False)

        if pagination_info or is_at_bottom:
            print(f"    📍 列表已加载完成")
            break

    if pagination_info:
        print(f"    📊 分页: 第 {pagination_info.get('currentPage', '?')}/{pagination_info.get('totalPages', '?')} 页")

    return {
        "pagination": pagination_info or {"hasNext": False, "currentPage": 1, "totalPages": 1},
        "next_button": None
    }


async def hover_and_find_view_button(editor_page, start_y, x_pos):
    """
    从指定位置开始向下移动鼠标，寻找【查看文章】按钮。
    鼠标移动时，如果 hover 到文章行上，会出现【查看文章】文字。

    策略：在当前可见区域内，用 JS 检查鼠标经过的位置是否有「查看文章」文字。

    Args:
        editor_page: 编辑器页面
        start_y: 开始的 Y 坐标
        x_pos: 鼠标移动的 X 坐标（放大镜的 X 位置）

    Returns:
        {x, y, title, date}: 找到的第一个【查看文章】按钮信息，没找到返回 None
    """
    result = await editor_page.evaluate("""(params) => {
        const { startY, xPos } = params;
        const viewportHeight = window.innerHeight;

        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }

        // 找所有可见的【查看文章】按钮
        const allEls = document.querySelectorAll('*');
        const candidates = [];

        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '查看文章' && el.children.length === 0) {
                const rect = el.getBoundingClientRect();
                // 只找在 start_y 下方的
                if (rect.top >= startY - 5) {
                    const c = getCenter(el);
                    if (c) {
                        candidates.push({
                            x: c.x,
                            y: c.y,
                            screenY: rect.top,
                            el: el
                        });
                    }
                }
            }
        }

        if (candidates.length === 0) return null;

        // 按从上到下排序，返回第一个
        candidates.sort((a, b) => a.screenY - b.screenY);
        const first = candidates[0];

        // 尝试获取关联的文章标题和日期
        // 【查看文章】按钮通常在文章行的右侧，同一行左侧有标题，下方有日期
        let title = '';
        let date = '';

        // 向上查找标题（同行或上一行的文字元素）
        let parent = first.el.parentElement;
        for (let depth = 0; depth < 6 && parent; depth++) {
            const texts = parent.querySelectorAll('span, div, p, a');
            for (const t of texts) {
                if (t.offsetParent === null || t === first.el) continue;
                const txt = t.textContent.trim();
                // 标题：长度 5-200，不含日期格式
                if (txt.length > 5 && txt.length < 200 && !txt.match(/\\d{4}-\\d{2}-\\d{2}/)
                    && !txt.includes('查看文章') && !title) {
                    title = txt;
                }
                // 日期
                const dateMatch = txt.match(/(\\d{4}-\\d{2}-\\d{2})/);
                if (dateMatch && !date) {
                    date = dateMatch[1];
                }
            }
            if (title && date) break;
            parent = parent.parentElement;
        }

        return { x: first.x, y: first.y, title, date };
    }""", {"startY": start_y, "xPos": x_pos})

    return result


async def mouse_scan_for_view_button(editor_page, start_y, scan_x, step=10, max_y=None):
    """
    鼠标物理扫描法：从指定 Y 位置开始，沿 X 轴向下逐行移动鼠标。
    鼠标 hover 到文章行时会触发【查看文章】按钮显示，JS 检测到后立即返回。

    Args:
        editor_page: 编辑器页面
        start_y: 开始扫描的 Y 坐标（视口坐标）
        scan_x: 鼠标移动的 X 坐标（文章行区域）
        step: 每次向下移动的像素（默认10px）
        max_y: 最大扫描到哪个 Y（默认视口底部 - 20）

    Returns:
        {x, y, title, date}: 找到的第一个【查看文章】按钮信息，没找到返回 None
    """
    viewport = editor_page.viewport_size or {"width": 1280, "height": 800}
    if max_y is None:
        max_y = viewport["height"] - 20

    current_y = start_y

    while current_y <= max_y:
        # 鼠标移到当前位置
        await editor_page.mouse.move(scan_x, current_y)
        await asyncio.sleep(0.03)  # 等待 hover 触发

        # JS 检查当前是否出现了【查看文章】按钮
        result = await editor_page.evaluate("""(scanY) => {
            const allEls = document.querySelectorAll('*');
            for (const el of allEls) {
                if (el.offsetParent === null) continue;
                const t = el.textContent.trim();
                if (t === '查看文章' && el.children.length === 0) {
                    const rect = el.getBoundingClientRect();
                    // 只找鼠标附近（scanY ± 30px）的按钮
                    if (rect.top >= scanY - 30 && rect.top <= scanY + 30) {
                        const cx = Math.round(rect.left + rect.width / 2);
                        const cy = Math.round(rect.top + rect.height / 2);

                        // 获取标题和日期
                        let title = '';
                        let date = '';
                        let parent = el.parentElement;
                        for (let depth = 0; depth < 6 && parent; depth++) {
                            const texts = parent.querySelectorAll('span, div, p, a');
                            for (const t of texts) {
                                if (t.offsetParent === null || t === el) continue;
                                const txt = t.textContent.trim();
                                const dateMatch = txt.match(/(\\d{4}-\\d{2}-\\d{2})/);
                                if (dateMatch && !date) date = dateMatch[1];
                                if (txt.length > 5 && txt.length < 200 && !dateMatch
                                    && !txt.includes('查看文章') && !title) {
                                    title = txt;
                                }
                            }
                            if (title && date) break;
                            parent = parent.parentElement;
                        }
                        return { x: cx, y: cy, title, date, elTop: rect.top };
                    }
                }
            }
            return null;
        }""", current_y)

        if result:
            return result

        current_y += step

    return None


async def scroll_list_to_top(editor_page, start_x=None, max_duration_ms=5000, step_px=5):
    """
    在文章列表弹窗中，模拟「鼠标长按拖拽」滚回顶部。

    操作方式：
    1. 先获取当前鼠标大致位置（文章列表区域中央）
    2. mouse.down() 按住不放
    3. 持续向上移动鼠标（模拟拖拽）
    4. 滚动到顶部 → mouse.up() 松手

    Args:
        editor_page: 编辑器页面
        start_x: 拖拽 X 坐标
        max_duration_ms: 最大拖拽时长
        step_px: 每次向上移动的像素

    Returns:
        bool: 是否成功滚回顶部
    """
    if start_x is None:
        anchor = await find_search_area_anchor(editor_page)
        if anchor:
            start_x = anchor["magnifier"]["x"] - 100
        else:
            viewport = editor_page.viewport_size or {"width": 1280, "height": 800}
            start_x = viewport["width"] // 2 + 100

    # 获取当前可滚动容器的滚动位置，确定当前视口中央对应的页面 Y
    scroll_info = await editor_page.evaluate("""() => {
        const scrollableEls = document.querySelectorAll(
            '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
        );
        for (const el of scrollableEls) {
            if (el.scrollHeight > el.clientHeight + 10) {
                return {
                    scrollTop: el.scrollTop,
                    scrollHeight: el.scrollHeight,
                    clientHeight: el.clientHeight
                };
            }
        }
        return {
            scrollTop: window.scrollY,
            scrollHeight: document.body.scrollHeight,
            clientHeight: window.innerHeight
        };
    }""")

    # 起始 Y 在视口中央偏下
    viewport = editor_page.viewport_size or {"width": 1280, "height": 800}
    current_y = viewport["height"] // 2 + 100

    print(f"    🖱️ 鼠标移到 ({start_x}, {current_y})")
    await editor_page.mouse.move(start_x, current_y)
    await editor_page.wait_for_timeout(200)

    await editor_page.mouse.down()
    await editor_page.wait_for_timeout(100)

    print(f"    ⬆️ 长按拖拽向上滚动...")

    start_time = time.time()
    max_seconds = max_duration_ms / 1000

    while time.time() - start_time < max_seconds:
        current_y -= step_px
        await editor_page.mouse.move(start_x, current_y)
        await asyncio.sleep(0.02)

        # 每移动 100px 检测一次是否到顶部
        moved = viewport["height"] // 2 + 100 - current_y
        if int(moved) % 100 >= step_px:
            continue

        at_top = await editor_page.evaluate("""() => {
            const scrollableEls = document.querySelectorAll(
                '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
            );
            for (const el of scrollableEls) {
                if (el.scrollHeight > el.clientHeight + 10) {
                    return el.scrollTop <= 5;
                }
            }
            return window.scrollY <= 5;
        }""")

        if at_top:
            print(f"    📍 已滚回顶部")
            break

    await editor_page.mouse.up()
    elapsed = time.time() - start_time
    print(f"    ✋ 松开鼠标（拖拽 {elapsed:.1f}s）")
    return True


async def scroll_list_down_a_bit(editor_page, scroll_amount=100):
    """
    在文章列表中，用滚动条滑块长按拖动方式向下滚动一小段距离。
    替代滚轮方式，避免 macOS 下方向/速度不稳定的问题。

    原理：
    1. 找到文章列表的可滚动容器
    2. 计算滚动条滑块当前位置
    3. 长按滑块，向下拖动 scroll_amount 像素（对应内容位移）
    4. 松手

    Args:
        editor_page: 编辑器页面
        scroll_amount: 向下滚动的内容像素（正数=向下，负数=向上）
    Returns:
        bool: 是否成功
    """
    result = await editor_page.evaluate("""() => {
        // 找文章列表的可滚动容器（scrollHeight > clientHeight）
        const allEls = Array.from(document.querySelectorAll('*'));
        let scrollableContainer = null;
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            if (el.scrollHeight > el.clientHeight + 20) {
                const r = el.getBoundingClientRect();
                // 容器应该在页面右侧（文章列表），且有一定大小
                if (r.width > 300 && r.height > 200 && r.left > 200) {
                    scrollableContainer = el;
                    break;
                }
            }
        }

        if (!scrollableContainer) return null;

        const container = scrollableContainer;
        const cRect = container.getBoundingClientRect();

        // 计算滚动比例
        const scrollableDistance = container.scrollHeight - container.clientHeight;
        const currentRatio = scrollableDistance > 0 ? container.scrollTop / scrollableDistance : 0;

        // 滚动条滑块宽度（估算）
        const scrollbarWidth = 8;
        const scrollbarTrackHeight = cRect.height - 20; // 上下各留 10px padding
        const thumbHeight = Math.max(30, scrollbarTrackHeight * (container.clientHeight / container.scrollHeight));
        const thumbCenterX = Math.round(cRect.right - scrollbarWidth / 2);
        const thumbCenterY = Math.round(cRect.top + 10 + thumbHeight / 2);

        // 当前位置
        const thumbY = thumbCenterY;

        return {
            thumbX: thumbCenterX,
            thumbY: thumbY,
            scrollTop: container.scrollTop,
            scrollableDistance: scrollableDistance,
            currentRatio: currentRatio,
            thumbHeight: thumbHeight,
            scrollbarTrackTop: cRect.top + 10,
            scrollbarTrackBottom: cRect.bottom - 10,
            containerTop: cRect.top,
            containerBottom: cRect.bottom,
            containerLeft: cRect.left,
            containerRight: cRect.right,
        };
    }""")

    if not result:
        print(f"  ⚠️ 未找到滚动条容器，尝试滚轮兜底")
        delta_y = -scroll_amount * 2
        await editor_page.mouse.wheel(0, delta_y)
        await editor_page.wait_for_timeout(200)
        return True

    thumb_x = result["thumbX"]
    thumb_y = result["thumbY"]
    scrollable_distance = result["scrollableDistance"]
    current_ratio = result["currentRatio"]
    track_top = result["scrollbarTrackTop"]
    track_bottom = result["scrollbarTrackBottom"]
    thumb_height = result["thumbHeight"]

    if scrollable_distance < 10:
        # 已经滚到底了
        return True

    # 计算目标滑块位置
    # 每次向下拖动的"滑块距离" = scroll_amount / scrollableDistance * trackScrollable
    track_scrollable = track_bottom - track_top - thumb_height
    thumb_delta = (scroll_amount / scrollable_distance) * track_scrollable if scrollable_distance > 0 else 0
    target_thumb_y = min(thumb_y + thumb_delta, track_bottom - thumb_height / 2)
    target_thumb_y = max(target_thumb_y, track_top + thumb_height / 2)

    # 方向：如果 scroll_amount 为负（向上），thumb_delta 为负
    if scroll_amount < 0:
        target_thumb_y = max(thumb_y + thumb_delta, track_top + thumb_height / 2)

    print(f"  ⬇️ 滚动条滑块: ({thumb_x}, {thumb_y}) → ({thumb_x}, {round(target_thumb_y)})")
    print(f"     当前位置比例: {current_ratio:.2%}, 剩余: {scrollable_distance:.0f}px")

    # 长按滑块，拖动到目标位置
    await editor_page.mouse.move(thumb_x, thumb_y)
    await editor_page.wait_for_timeout(100)
    await editor_page.mouse.down()
    await editor_page.wait_for_timeout(100)

    # 分3次小拖动，更稳定
    steps = 3
    for i in range(1, steps + 1):
        t = i / steps
        cur_y = thumb_y + (target_thumb_y - thumb_y) * t
        await editor_page.mouse.move(thumb_x, round(cur_y))
        await asyncio.sleep(0.05)

    await editor_page.mouse.up()
    await editor_page.wait_for_timeout(200)
    return True


async def find_first_article_after_dropdown(editor_page):
    """
    滚到底部后，找到关闭按钮【X】的位置，
    然后在【X】左下方找下拉后的第一篇文章（【查看文章】按钮）。
    
    返回：
        dict: {
            close_x, close_y,   # 关闭按钮位置
            first_article_x, first_article_y,  # 第一篇文章【查看文章】按钮位置
            first_article_title,               # 第一篇文章标题
            first_article_date                  # 第一篇文章日期
        }
        如果找不到返回 None
    """
    result = await editor_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }
        
        // 找关闭按钮【X】
        // 策略1：通过 aria-label 找
        // 策略2：通过 textContent 找单个 X/×/✕
        // 策略3：通过类名找 close 相关的
        let closeBtn = null;
        let closeCenter = null;
        const allEls = Array.from(document.querySelectorAll('*'));
        
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
            const className = (el.className || '').toLowerCase();
            
            // 关闭按钮特征：
            // 1. aria-label 包含 close / ×
            // 2. 单独一个 X 或 ×，且在页面右侧
            // 3. 类名包含 close / dismiss
            
            if (ariaLabel.includes('close') || ariaLabel === '×') {
                const c = getCenter(el);
                if (c) { closeBtn = el; closeCenter = c; break; }
            }
            
            const className = String(el.className || '').toLowerCase();
            
            if (className.includes('close') || className.includes('dismiss')) {
                const c = getCenter(el);
                if (c) { closeBtn = el; closeCenter = c; break; }
            }
            
            // 单独一个 X，且在页面右侧
            if ((t === 'X' || t === '×' || t === '✕') && el.children.length === 0) {
                const r = el.getBoundingClientRect();
                if (r.right > 500 && r.top < 300) {
                    const c = getCenter(el);
                    if (c) { closeBtn = el; closeCenter = c; break; }
                }
            }
        }
        
        // 如果还是找不到，尝试找弹窗右上角的元素
        if (!closeBtn) {
            // 找所有在页面右侧上半部分的按钮
            for (const el of allEls) {
                if (el.offsetParent === null) continue;
                const r = el.getBoundingClientRect();
                // 在页面右侧上半部分
                if (r.right > 600 && r.top < 200 && r.width < 50 && r.height < 50) {
                    const c = getCenter(el);
                    if (c) { closeBtn = el; closeCenter = c; break; }
                }
            }
        }
        
        if (!closeBtn || !closeCenter) return null;
        
        // 找第一篇文章的【查看文章】按钮
        // 在关闭按钮左下方（关闭按钮通常是弹窗右上角，左下方就是文章列表区域）
        let firstArticleBtn = null;
        
        // 查找所有包含"查看文章"文字的按钮/元素
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '查看文章') {
                const r = el.getBoundingClientRect();
                // 在关闭按钮左下方区域内
                // 关闭按钮左下方的意思：Y > close_y（关闭按钮下方），X < close_x（关闭按钮左边）
                if (r.left < closeCenter.x && r.top > closeCenter.y - 100) {
                    if (!firstArticleBtn || r.top < firstArticleBtn.top) {
                        firstArticleBtn = el;
                    }
                }
            }
        }
        
        if (!firstArticleBtn) return null;
        
        const firstBtnCenter = getCenter(firstArticleBtn);
        if (!firstBtnCenter) return null;
        
        // 获取文章标题和日期
        let title = '';
        let date = '';
        
        // 查找文章标题（按钮上方的文字）
        const parent = firstArticleBtn.closest('[class*="item"], [class*="article"], [class*="msg"], [class*="list"]') || firstArticleBtn.parentElement;
        if (parent) {
            const titleEl = parent.querySelector('[class*="title"], [class*="name"], strong, b, p');
            if (titleEl) {
                title = titleEl.textContent.trim().slice(0, 100);
            }
            
            // 查找日期
            const dateEls = parent.querySelectorAll('[class*="date"], [class*="time"]');
            if (dateEls.length > 0) {
                date = dateEls[dateEls.length - 1].textContent.trim();
            }
        }
        
        return {
            close_x: closeCenter.x,
            close_y: closeCenter.y,
            first_article_x: firstBtnCenter.x,
            first_article_y: firstBtnCenter.y,
            first_article_title: title,
            first_article_date: date
        };
    }""")
    
    if result:
        print(f"    ✕ 关闭按钮位置: ({result['close_x']}, {result['close_y']})")
        print(f"    📰 下拉后第一篇文章: {result['first_article_title'][:50] or '未知'}")
        print(f"       位置: ({result['first_article_x']}, {result['first_article_y']})")
    else:
        print(f"    ⚠️ 未找到关闭按钮或下拉后第一篇文章")
    
    return result


async def find_next_page_button(editor_page):
    """
    在当前可见区域查找下一页按钮（> 或 › 或 »）。

    Returns:
        {x, y} 坐标，找不到返回 None
    """
    pos = await editor_page.evaluate("""() => {
        function getCenter(el) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) return null;
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) };
        }
        const allEls = document.querySelectorAll('*');
        for (const el of allEls) {
            if (el.offsetParent === null) continue;
            const t = el.textContent.trim();
            if (t === '>' || t === '›' || t === '»' || el.getAttribute('aria-label') === '下一页') {
                const c = getCenter(el);
                if (c) return c;
            }
        }
        return null;
    }""")
    return pos


async def close_article_and_return(editor_page, article_page, context):
    """
    关闭文章页面，返回编辑器页面。

    Returns:
        (bool, page): (是否成功, 可用的编辑器页面或 None)
    """
    closed_article = False
    if article_page:
        try:
            await article_page.close()
            print(f"    ✅ 文章页面已关闭")
            closed_article = True
        except Exception:
            # 页面可能已经关闭了
            print(f"    ℹ️ 文章页面已关闭（或无法关闭）")
            closed_article = True

    # 验证编辑器页面仍然存活
    try:
        await editor_page.evaluate("1+1")
        return True, editor_page
    except Exception:
        # 编辑器页面已失效，尝试恢复
        print(f"    ⚠️ 编辑器页面已失效，尝试恢复...")
        pages = context.pages
        for p in pages:
            try:
                if p.url and 'mp.weixin.qq.com' in p.url:
                    await p.evaluate("1+1")
                    print(f"    ✅ 已恢复到: {p.url[:60]}...")
                    return True, p
            except Exception:
                continue
        print(f"    ❌ 无法恢复编辑器页面")
        return False, None


# ─────────────────────────────────────────────
#  主爬取流程（视觉扫描法 v3）
# ─────────────────────────────────────────────

async def crawl_articles(account_name, days, cdp_url="http://localhost:9222", agent_mode: bool = False):
    """
    主爬取函数（视觉扫描法 v3）：

    1. 登录 → 进入草稿箱 → 新建草稿 → 打开超链接弹窗 → 搜索公众号 → 选择搜索结果
    2. 定位搜索框 + 🔍放大镜（阶段B）
    3. 从放大镜往下找到第一篇【查看文章】→ 先爬取第一篇（阶段A0）
    4. JS scrollTop 一步到底，加载完整文章列表 → JS scrollTop=0 回到顶部（阶段A）
    5. 鼠标滚轮微滑 + 鼠标物理扫描交替（阶段C）：
       - 从视口顶部（Y=0）沿放大镜X轴逐行下移，hover触发【查看文章】
       - 扫完一个视口没找到 → mouse.wheel 微滚100px → JS检测scrollTop位移判断是否到底
       - 到底后启动15秒倒计时继续扫描，超时后进入翻页
    6. 翻页：用【跳转】功能输入页码跳到下一页 → JS scrollTop=0 回顶 → 重复步骤2-5
    7. 日期超出范围 → 停止

    阶段A（滚到底/回顶）使用 JS scrollTop（快速稳定），
    阶段C（微滑动）使用 mouse.wheel 模拟鼠标滚轮（macOS deltaY负数=视口向下）。

    日期范围包含头尾两天：start_date = N天前 00:00:00，end_date = 当天 23:59:59
    """
    start_date, end_date = parse_date_range(days)
    print(f"📅 筛选时间范围：{start_date.strftime('%Y-%m-%d')} 至 {end_date.strftime('%Y-%m-%d')}")

    async with async_playwright() as p:
        browser = await p.chromium.connect_over_cdp(cdp_url)
        context = browser.contexts[0] if browser.contexts else await browser.new_context()
        page = context.pages[0] if context.pages else await context.new_page()

        # ── 检查登录状态 ──
        login_status = await check_login(page)
        if login_status == "unknown":
            await page.goto("https://mp.weixin.qq.com", wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(1500)
            login_status = await check_login(page)

        if login_status == "need_login":
            print("❌ 未登录，请先扫码登录")
            return None

        if login_status != "logged_in":
            print("❌ 无法确认登录状态，请确保影刀浏览器已打开微信公众号后台")
            return None

        print("✅ 已登录，开始爬取流程...")

        # 导航到草稿箱
        await navigate_to_draft(page)
        print("  ✅ 已进入草稿箱")
        await page.wait_for_timeout(2000)

        # 新建草稿
        editor_page = await create_new_draft(context, page)
        print("  ✅ 已打开编辑器")

        # 搜索公众号
        result = await search_account(editor_page, account_name, stop_before_dropdown=agent_mode)

        # Agent 模式：停止并返回状态
        if agent_mode:
            print(f"  ✅ 已搜索公众号：{account_name}")
            return {
                "status": "ready_for_agent",
                "account_name": account_name,
                "editor_page": editor_page,
                "context": context,
                "start_date": start_date,
                "end_date": end_date,
                "days": days
            }

        # ── 脚本模式：自动完成全部操作 ──
        print(f"  ✅ 已搜索并选择公众号：{account_name}")

        # 等待页面稳定
        try:
            await editor_page.wait_for_timeout(3000)
        except Exception:
            print(f"  ⚠️ 编辑器页面已变更，尝试恢复...")
            pages = context.pages
            for p in reversed(pages):
                if p.url and 'mp.weixin.qq.com' in p.url and p != page:
                    editor_page = p
                    break
            if len(context.pages) > 1 and editor_page == page:
                editor_page = context.pages[-1]

        # ═══════════════════════════════════════════════════════
        #  核心遍历逻辑：视觉扫描法 v3
        # ═══════════════════════════════════════════════════════

        all_articles = []
        page_num = 1
        processed_titles = set()

        while True:
            print(f"\n{'='*60}")
            print(f"  📄 第 {page_num} 页")

            # ── 阶段B：定位搜索框 + 放大镜（扫描起点）──
            print(f"  📍 定位搜索区域...")
            try:
                anchor = await find_search_area_anchor(editor_page)
            except Exception as e:
                print(f"  ⚠️ 定位搜索区域失败: {e}")
                break

            if not anchor:
                print(f"  ⚠️ 未找到搜索区域")
                break

            magnifier_x = anchor["magnifier"]["x"]
            magnifier_y = anchor["magnifier"]["y"]
            print(f"  🔍 放大镜位置: ({magnifier_x}, {magnifier_y})")

            # ── 阶段A0：先抓取第一篇文章（避免滚到底再滚回来时漏掉）──
            print(f"  📰 先检查第一篇文章...")
            scan_y = magnifier_y + 20
            first_article_crawled = False
            stop_crawl = False

            try:
                first_btn = await hover_and_find_view_button(editor_page, scan_y, magnifier_x)
                if first_btn:
                    first_title = first_btn.get("title", "")
                    first_date_str = first_btn.get("date", "")
                    first_btn_x = first_btn["x"]
                    first_btn_y = first_btn["y"]

                    # 跳过已处理
                    if first_title and first_title not in processed_titles:
                        article_date = parse_article_date(first_date_str)
                        # 日期检查：早于起始日期则停止整个爬取
                        if article_date and article_date < start_date:
                            print(f"  ⏹️ 第一篇日期 {article_date.strftime('%Y-%m-%d')} 早于起始日期，停止")
                            stop_crawl = True
                        elif not article_date or is_in_date_range(article_date, start_date, end_date):
                            print(f"  📰 第一篇: {first_title[:50]}")
                            print(f"     日期: {first_date_str or '未知'}")

                            await editor_page.mouse.move(first_btn_x, first_btn_y)
                            await editor_page.wait_for_timeout(300)
                            article_page = await click_view_article_button(editor_page, first_btn_x, first_btn_y)

                            if article_page:
                                try:
                                    content = await extract_article_content(article_page)
                                    content["account"] = account_name
                                    all_articles.append(content)
                                    print(f"     ✅ 提取成功: {content['title'][:30]}")
                                    processed_titles.add(first_title)
                                    first_article_crawled = True
                                except Exception as e:
                                    print(f"     ⚠️ 提取失败: {e}")
                                finally:
                                    ok, recovered_page = await close_article_and_return(editor_page, article_page, context)
                                    if not ok:
                                        print(f"     ❌ 编辑器页面丢失，终止")
                                        stop_crawl = True
                                    elif recovered_page and recovered_page != editor_page:
                                        editor_page = recovered_page
                                        print(f"     🔄 已切换编辑器页面")
                                    await asyncio.sleep(0.3)
                            else:
                                print(f"     ⚠️ 未能打开文章页面")
                        else:
                            print(f"  ⏭️ 第一篇 {first_title[:30]} ({first_date_str}) - 超出范围，跳过")
                else:
                    print(f"  ℹ️ 未找到第一篇【查看文章】按钮")

                # 第一篇爬完后微滑100px
                try:
                    await editor_page.mouse.move(magnifier_x, magnifier_y)
                    await asyncio.sleep(0.3)
                    await editor_page.mouse.wheel(0, 100)
                    await asyncio.sleep(0.3)
                except Exception:
                    pass

            except Exception as e:
                print(f"  ⚠️ 抓取第一篇文章时出错: {e}")

            if stop_crawl:
                break

            # ── 阶段A：先JS滚到底部，加载完整列表（确认总页数和总文章数）──
            # 用JS scrollTop一步到位，加载完整列表后再回到顶部开始逐篇扫描
            print(f"  ⬇️ 用JS滚动到底部加载完整列表...")
            bottom_info = await scroll_list_to_bottom_js(editor_page)

            pagination = bottom_info.get("pagination", {})
            total_pages = pagination.get("totalPages", 0)

            if total_pages:
                print(f"  📊 分页: 共 {total_pages} 页")

            # 用JS scrollTop=0 瞬间回到顶部，开始逐篇扫描
            await editor_page.evaluate("""() => {
                const scrollableEls = document.querySelectorAll(
                    '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
                );
                for (const el of scrollableEls) {
                    if (el.scrollHeight > el.clientHeight + 10) {
                        el.scrollTop = 0;
                        return;
                    }
                }
                window.scrollTo(0, 0);
            }""")
            await asyncio.sleep(0.5)
            print(f"  📍 JS scrollTop=0 回到列表顶部")

            # ── 阶段C：微滑动 + 鼠标物理扫描交替 ──
            # 流程：从视口顶部沿放大镜X轴往下扫 → 扫完视口 → mouse.wheel微滚100px → 再扫 → 直到连续多次扫不到
            # ⚠️ 拉到底之后才开始计时，超过15秒直接跳出进入翻页
            import time as _time
            phase_c_bottom_time = None  # 到底后的计时起点（到底后才开始计时）
            phase_c_bottom_timeout = 15.0  # 秒，到底后继续扫描的最长时间

            scan_y = 0  # 每次扫描从视口顶部开始
            scan_x = magnifier_x  # 沿放大镜X轴
            print(f"  🔍 鼠标从视口顶部 Y={scan_y} 沿 X={scan_x} 向下扫描...")

            articles_on_this_page = 0
            no_button_count = 0
            max_no_button = 2  # 连续2次（视口扫描+微滚）找不到就认为本页已处理完

            while True:
                # ⚠️ 超时检查：到底后继续扫描超过15秒，直接跳出进入翻页
                if phase_c_bottom_time and _time.time() - phase_c_bottom_time > phase_c_bottom_timeout:
                    print(f"  ⏱️ 到底后扫描超时（{phase_c_bottom_timeout}秒），直接进入翻页")
                    break

                # 鼠标从 scan_y 开始沿 scan_x 向下移动，hover 触发【查看文章】
                try:
                    btn_info = await mouse_scan_for_view_button(editor_page, scan_y, scan_x, step=10)
                except Exception as e:
                    print(f"  ⚠️ 鼠标扫描异常（页面可能被销毁）: {e}")
                    # 尝试恢复编辑器页面
                    ok, recovered_page = await close_article_and_return(editor_page, None, context)
                    if not ok:
                        print(f"     ❌ 编辑器页面丢失，终止")
                        stop_crawl = True
                        break
                    if recovered_page and recovered_page != editor_page:
                        editor_page = recovered_page
                        print(f"     🔄 已切换编辑器页面")
                    # 重新定位搜索区域
                    try:
                        anchor = await find_search_area_anchor(editor_page)
                        if anchor and anchor.get("found"):
                            scan_x = anchor.get("magnifier_x", scan_x)
                            magnifier_x = scan_x
                            magnifier_y = anchor.get("magnifier_y", magnifier_y)
                            print(f"     📍 重新定位搜索区域: ({magnifier_x}, {magnifier_y})")
                    except Exception:
                        pass
                    continue

                if btn_info:
                    no_button_count = 0
                    title = btn_info.get("title", "")
                    date_str = btn_info.get("date", "")
                    btn_x = btn_info["x"]
                    btn_y = btn_info["y"]

                    # 跳过已处理的文章
                    if title and title in processed_titles:
                        print(f"  ⏭️ 已处理: {title[:30]}... 跳过")
                        scan_y = btn_y + 50
                        continue

                    # 日期检查
                    article_date = parse_article_date(date_str)
                    if article_date and article_date < start_date:
                        print(f"  ⏹️ 日期 {article_date.strftime('%Y-%m-%d')} 早于起始日期，停止")
                        stop_crawl = True
                        break

                    if article_date and not is_in_date_range(article_date, start_date, end_date):
                        print(f"  ⏭️ {title[:30]} ({date_str}) - 超出范围，跳过")
                        scan_y = btn_y + 50
                        continue

                    print(f"\n  📰 {title[:50]}")
                    print(f"     日期: {date_str or '未知'}")
                    print(f"     【查看文章】: ({btn_x}, {btn_y})")

                    # 鼠标移到按钮位置 → 点击
                    await editor_page.mouse.move(btn_x, btn_y)
                    await editor_page.wait_for_timeout(300)
                    article_page = await click_view_article_button(editor_page, btn_x, btn_y)

                    if not article_page:
                        # 点击失败，重试一次
                        print(f"     🔄 重试...")
                        await asyncio.sleep(0.5)
                        btn_info_retry = await mouse_scan_for_view_button(editor_page, btn_y - 30, scan_x, step=10, max_y=btn_y + 30)
                        if btn_info_retry:
                            await editor_page.mouse.move(btn_info_retry["x"], btn_info_retry["y"])
                            await editor_page.wait_for_timeout(300)
                            article_page = await click_view_article_button(editor_page, btn_info_retry["x"], btn_info_retry["y"])

                    if article_page:
                        try:
                            content = await extract_article_content(article_page)
                            content["account"] = account_name
                            all_articles.append(content)
                            print(f"     ✅ 提取成功: {content['title'][:30]}")
                            articles_on_this_page += 1
                        except Exception as e:
                            print(f"     ⚠️ 提取失败: {e}")
                        finally:
                            ok, recovered_page = await close_article_and_return(editor_page, article_page, context)
                            if not ok:
                                print(f"     ❌ 编辑器页面丢失，终止")
                                stop_crawl = True
                                break
                            if recovered_page and recovered_page != editor_page:
                                editor_page = recovered_page
                                print(f"     🔄 已切换编辑器页面")
                            if title:
                                processed_titles.add(title)
                            await asyncio.sleep(0.3)
                    else:
                        print(f"     ⚠️ 未能打开文章页面")
                        try:
                            await editor_page.evaluate("1+1")
                        except Exception:
                            ok, recovered_page = await close_article_and_return(editor_page, None, context)
                            if not ok:
                                stop_crawl = True
                                break
                            if recovered_page and recovered_page != editor_page:
                                editor_page = recovered_page

                    # 爬完一篇，先微滑100px让下一篇文章进入视口
                    try:
                        await editor_page.mouse.move(magnifier_x, magnifier_y)
                        await asyncio.sleep(0.3)
                        await editor_page.mouse.wheel(0, 100)
                        await asyncio.sleep(0.3)
                        # 微滑后从视口顶部重新扫描（因为内容已经滑动）
                        scan_y = 0
                    except Exception:
                        scan_y = btn_y + 50
                else:
                    # 从 scan_y 扫到视口底部没找到【查看文章】
                    no_button_count += 1
                    print(f"  🔍 当前视口无【查看文章】(连续{no_button_count}/{max_no_button}次)")

                    if no_button_count >= max_no_button:
                        # 到底状态下（phase_c_bottom_time 已设置）不靠计数退出，只靠超时
                        if phase_c_bottom_time is None:
                            print(f"  📍 本页已扫描完毕")
                            break

                    # 扫不到时，微滚100px + JS检测是否真的滚动到位（判断是否到底）
                    await editor_page.mouse.move(magnifier_x, magnifier_y)
                    await asyncio.sleep(0.3)

                    # 记录滚动前位置
                    try:
                        scroll_before = await editor_page.evaluate("""() => {
                            const els = document.querySelectorAll(
                                '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
                            );
                            for (const el of els) {
                                if (el.scrollHeight > el.clientHeight + 10) return el.scrollTop;
                            }
                            return window.scrollY;
                        }""")
                    except Exception:
                        scroll_before = 0

                    await editor_page.mouse.wheel(0, 100)
                    await asyncio.sleep(0.4)

                    # 记录滚动后位置，判断是否滚动了
                    try:
                        scroll_after = await editor_page.evaluate("""() => {
                            const els = document.querySelectorAll(
                                '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
                            );
                            for (const el of els) {
                                if (el.scrollHeight > el.clientHeight + 10) return el.scrollTop;
                            }
                            return window.scrollY;
                        }""")
                    except Exception:
                        scroll_after = 0

                    scrolled = abs(scroll_after - scroll_before) > 5 if scroll_before is not None and scroll_after is not None else False

                    if not scrolled:
                        # 没有实际滚动 = 已经到底了
                        if phase_c_bottom_time is None:
                            # 第一次到底，开始计时，给15秒时间继续扫描
                            phase_c_bottom_time = _time.time()
                            scan_y = 0  # 重置扫描起点
                            no_button_count = 0  # 重置计数，到底后不再用计数退出，只靠超时
                            print(f"  📍 微滚100px未产生位移，判定已到底部，开始15秒倒计时继续扫描")
                        else:
                            # 已经在计时了，等超时检查自动跳出
                            print(f"  📍 已到底部，继续扫描中（剩余{max(0, phase_c_bottom_timeout - (_time.time() - phase_c_bottom_time)):.1f}秒）")
                    else:
                        scan_y = 0  # 内容有变化，从视口顶部重新扫描
                        # 滚动成功说明还没到底，重置到底计时
                        phase_c_bottom_time = None
                        no_button_count = 0
                        print(f"  📜 微滚100px，滚动成功，重新从Y=0扫描")

            if stop_crawl:
                break

            print(f"  📈 本页处理了 {articles_on_this_page} 篇文章")

            # ── 阶段D：翻页 ──
            # 直接用阶段A拿到的分页信息判断是否有下一页，不再重复滚到底轮询等待
            total_pages = pagination.get("totalPages", 0)
            has_next = page_num < total_pages if total_pages > 0 else False

            # 快速JS滚到底部，让分页控件可见（一次到位，不等轮询）
            print(f"  ⬇️ 翻页：JS快速滚到底部...")
            try:
                await editor_page.evaluate("""() => {
                    const scrollableEls = document.querySelectorAll(
                        '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
                    );
                    for (const el of scrollableEls) {
                        if (el.scrollHeight > el.clientHeight + 10) {
                            el.scrollTop = el.scrollHeight - el.clientHeight;
                            return;
                        }
                    }
                    window.scrollTo(0, document.body.scrollHeight);
                }""")
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"  ⚠️ 翻页前滚动失败: {e}")

            # 兜底：即使分页解析为0，如果已经处理了文章也尝试翻页
            if not has_next and articles_on_this_page > 0:
                has_next = True

            if has_next:
                next_page = page_num + 1  # 目标页码
                print(f"  ➡️ 跳转到第 {next_page} 页...")

                try:
                    # 第1步：用 JS 找到【跳转】旁边的输入框坐标
                    input_coords = await editor_page.evaluate(f"""() => {{
                        const allEls = document.querySelectorAll('*');
                        for (const el of allEls) {{
                            if (el.offsetParent === null) continue;
                            const t = el.textContent.trim();
                            if (t === '跳转') {{
                                let input = null;
                                // 找父级中的 input
                                let parent = el.parentElement;
                                for (let i = 0; i < 5 && parent; i++) {{
                                    input = parent.querySelector('input[type="text"], input[type="number"], input:not([type]), textarea');
                                    if (input) break;
                                    parent = parent.parentElement;
                                }}
                                // 找前一个兄弟元素中的 input
                                if (!input) {{
                                    let prev = el.previousElementSibling;
                                    for (let i = 0; i < 5 && prev; i++) {{
                                        input = prev.querySelector('input[type="text"], input[type="number"], input:not([type]), textarea');
                                        if (input) break;
                                        prev = prev.previousElementSibling;
                                    }}
                                }}
                                if (input) {{
                                    const r = input.getBoundingClientRect();
                                    return {{
                                        x: Math.round(r.left + r.width / 2),
                                        y: Math.round(r.top + r.height / 2),
                                        found: true
                                    }};
                                }}
                            }}
                        }}
                        return {{ found: false }};
                    }}""")

                    if not input_coords.get("found"):
                        print(f"  ⚠️ 未找到跳转输入框，翻页终止")
                        break

                    # 第2步：鼠标点击输入框，用键盘输入页码
                    print(f"  🖱️ 点击输入框: ({input_coords['x']}, {input_coords['y']})")
                    await editor_page.mouse.click(input_coords["x"], input_coords["y"])
                    await editor_page.wait_for_timeout(300)
                    # 清空原有内容并输入新页码
                    await editor_page.keyboard.press("Meta+a")  # Mac 全选
                    await editor_page.wait_for_timeout(100)
                    await editor_page.keyboard.type(str(next_page))
                    await editor_page.wait_for_timeout(500)

                    # 第3步：用文本定位找到【跳转】按钮中心坐标，鼠标点击
                    jump_btn_pos = await find_text_by_ocr_fallback(editor_page, "跳转")
                    if jump_btn_pos:
                        print(f"  🖱️ 点击【跳转】: ({jump_btn_pos['x']}, {jump_btn_pos['y']})")
                        await editor_page.mouse.click(jump_btn_pos["x"], jump_btn_pos["y"])
                    else:
                        print(f"  ⚠️ 未定位到【跳转】按钮，翻页终止")
                        break

                    await editor_page.wait_for_timeout(2500)
                    page_num += 1

                    # 翻页成功后，用JS把scrollTop设为0回到顶部
                    print(f"  ⬆️ 翻页完成，JS scrollTop=0 回到顶部...")
                    await editor_page.evaluate("""() => {
                        const scrollableEls = document.querySelectorAll(
                            '[class*="scroll"], [class*="list"], [class*="dropdown"], [class*="popup"], [class*="container"]'
                        );
                        for (const el of scrollableEls) {
                            if (el.scrollHeight > el.clientHeight + 10) {
                                el.scrollTop = 0;
                                return;
                            }
                        }
                        window.scrollTo(0, 0);
                    }""")
                except Exception as e:
                    print(f"  ⚠️ 翻页失败: {e}")
                    break
            else:
                print(f"  ℹ️ 已到最后一页 (第 {page_num} 页)")
                break

        # 输出结果
        print(f"\n{'='*60}")
        print(f"🎉 爬取完成！共获取 {len(all_articles)} 篇文章")
        print(f"{'='*60}")

        if all_articles:
            print(f"\n📝 文章列表：")
            for i, article in enumerate(all_articles, 1):
                print(f"\n{i}. {article['title']}")
                print(f"   公众号：{article['account']}")
                print(f"   发布时间：{article['publish_date']}")
                print(f"   链接：{article['url']}")

        return all_articles


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="微信公众号资讯采集工具（zixun skill）")
    parser.add_argument("--account", required=True, help="公众号名称")
    parser.add_argument("--days", type=int, default=7, help="往前推算的天数")
    parser.add_argument("--cdp-url", default="http://localhost:9222", help="CDP 连接地址")
    parser.add_argument("--output-json", help="将结果保存为 JSON 文件（可选）")
    parser.add_argument("--agent-mode", action="store_true", 
                        help="Agent 模式：在搜索完成后停止，由 Agent 接手处理下拉框交互")
    args = parser.parse_args()

    result = asyncio.run(crawl_articles(args.account, args.days, args.cdp_url, agent_mode=args.agent_mode))

    if result is None:
        print("请先登录后再试")
        exit(1)

    # Agent 模式：脚本已完成搜索，输出状态后退出
    if args.agent_mode:
        if isinstance(result, dict) and result.get("status") == "ready_for_agent":
            print("\n✅ Agent 模式完成，浏览器保持打开状态，可由 Agent 通过 CDP 继续操作")
        exit(0)

    # 完整模式：输出结果（zixun 只需4个字段，不需要 content 正文）
    if args.output_json and result:
        output_data = []
        for a in result:
            output_data.append({
                "title": a.get("title", ""),
                "account": a.get("account", ""),
                "publish_date": a.get("publish_date", ""),
                "url": a.get("url", "")
            })
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"💾 结果已保存到 {args.output_json}")

    if result:
        print("\n" + "=" * 60)
        print("爬取结果摘要：")
        print("=" * 60)
        for i, article in enumerate(result, 1):
            print(f"\n{i}. {article['title']}")
            print(f"   公众号：{article['account']}")
            print(f"   发布时间：{article['publish_date']}")
            print(f"   链接：{article['url']}")
