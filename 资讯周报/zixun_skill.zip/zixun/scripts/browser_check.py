#!/usr/bin/env python3
"""
影刀浏览器启动与状态检测脚本

用法：
  python3 browser_check.py            # 检测 + 必要时启动，输出 JSON 状态
  python3 browser_check.py --status   # 只检测，不启动
  python3 browser_check.py --login    # 检测 + 启动 + 判断登录状态
"""

import sys
import json
import time
import subprocess
import urllib.request
import urllib.error
import argparse
import asyncio

CDP_URL = "http://localhost:9222"
BROWSER_PATH = (
    "/Applications/影刀.app/Contents/Resources/app/node_modules/"
    "xbot-browser/lib/影刀浏览器.app/Contents/MacOS/影刀浏览器"
)
TARGET_URL = "https://mp.weixin.qq.com"


def is_browser_running(timeout: float = 1.0) -> bool:
    """快速检测 CDP 端口是否可用"""
    try:
        urllib.request.urlopen(f"{CDP_URL}/json/version", timeout=timeout)
        return True
    except Exception:
        return False


def start_browser() -> bool:
    """后台启动影刀浏览器，轮询等待就绪（最多 15 秒）"""
    try:
        subprocess.Popen(
            [BROWSER_PATH, f"--remote-debugging-port=9222", TARGET_URL],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
    except FileNotFoundError:
        return False

    # 轮询等待，每 500ms 一次，最多 15 秒
    for _ in range(30):
        if is_browser_running(timeout=1.0):
            return True
        time.sleep(0.5)
    return False


async def get_login_status() -> str:
    """
    通过 Playwright 检查登录状态。
    返回: "logged_in" | "need_login" | "unknown"
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return "unknown"

    async with async_playwright() as p:
        try:
            browser = await p.chromium.connect_over_cdp(CDP_URL)
            context = browser.contexts[0] if browser.contexts else None
            if not context:
                return "unknown"
            page = context.pages[0] if context.pages else await context.new_page()

            url = page.url
            if "cgi-bin/home" in url or "cgi-bin/appmsg" in url or "cgi-bin/index" in url:
                return "logged_in"

            qrcode = page.locator(".login__type__container__scan__qrcode img")
            if await qrcode.count() > 0 and await qrcode.is_visible():
                return "need_login"

            dashboard = page.locator(
                ".weui-desktop-account__nickname, .weui-desktop-sidebar, .main_bd"
            )
            if await dashboard.count() > 0:
                return "logged_in"

            return "unknown"
        except Exception:
            return "unknown"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--status", action="store_true", help="只检测，不启动")
    parser.add_argument("--login", action="store_true", help="检测+启动+判断登录状态")
    args = parser.parse_args()

    result = {}

    # 1. 检测浏览器是否运行
    running = is_browser_running()
    result["browser_running"] = running

    if args.status:
        print(json.dumps(result, ensure_ascii=False))
        return

    # 2. 未运行则启动
    if not running:
        started = start_browser()
        result["browser_started"] = started
        result["browser_running"] = started
        if not started:
            result["error"] = "影刀浏览器启动失败，请检查安装路径"
            print(json.dumps(result, ensure_ascii=False))
            sys.exit(1)
    else:
        result["browser_started"] = False  # 已在运行，无需启动

    # 3. 检查登录状态（默认总是检查，--status 模式已在上方提前返回）
    login_status = asyncio.run(get_login_status())
    result["login_status"] = login_status

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
